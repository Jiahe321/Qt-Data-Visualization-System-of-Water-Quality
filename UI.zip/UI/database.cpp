#include "database.hpp"
#include <iostream>
#include <stdexcept>

// Initialize SQLite database connection
WaterSampleDatabase::WaterSampleDatabase(const std::string& dbName) {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(QString::fromStdString(dbName));

    if (!db.open()) {
        std::cerr << "Error: Unable to open database!" << std::endl;
    }
}

// Clear the database before reading new data
void WaterSampleDatabase::clearDatabase() {
    QSqlQuery query(db);
    query.exec("DELETE FROM water_samples");
}

// Create table
bool WaterSampleDatabase::createTable() {
    QSqlQuery query;
    const QString createTableSQL = R"(
        CREATE TABLE IF NOT EXISTS water_samples (
            id TEXT PRIMARY KEY,
            samplingPoint TEXT,
            samplingPointNotation TEXT,
            samplingPointLabel TEXT,
            sampleDateTime TEXT,
            determinandLabel TEXT,
            determinandDefinition TEXT,
            determinandNotation TEXT,
            resultQualifierNotation TEXT,
            result REAL,
            unitLabel TEXT,
            sampledMaterialTypeLabel TEXT,
            isComplianceSample INTEGER,
            samplePurpose TEXT,
            easting INTEGER,
            northing INTEGER
        )
    )";

    if (!query.exec(createTableSQL)) {
        std::cerr << "Failed to create or verify table: "
            << query.lastError().text().toStdString() << std::endl;
        return false;
    }
    return true;
}

bool WaterSampleDatabase::readCSV(const std::string& filename) {
    try {
        clearDatabase(); // Clear the database before inserting new data
        csv::CSVReader reader(filename);

        // Get the headers from the CSV file
        auto colNames = reader.get_col_names();
        std::set<std::string> headers(colNames.begin(), colNames.end());

        std::vector<std::string> expectedColumns = {
            "@id", "sample.samplingPoint", "sample.samplingPoint.notation",
            "sample.samplingPoint.label", "sample.sampleDateTime",
            "determinand.label", "determinand.definition",
            "determinand.notation", "resultQualifier.notation", "result",
            "determinand.unit.label", "sample.sampledMaterialType.label",
            "sample.isComplianceSample", "sample.purpose.label",
            "sample.samplingPoint.easting", "sample.samplingPoint.northing"
        };

        // Check if all required columns are present
        for (const auto& col : expectedColumns) {
            if (headers.find(col) == headers.end()) {
                // Column missing, throw an error or return false
                std::cerr << "Missing required column: " << col << std::endl;
                return false;
            }
        }

        std::vector<WaterSample> samples; // Vector to hold parsed WaterSample objects

        // Iterate over each row in the CSV
        for (const auto& row : reader) {
            try {
                // Parse values from the row
                std::string id = row["@id"].get<>();
                std::string samplingPoint = row["sample.samplingPoint"].get<>();
                std::string samplingPointNotation = row["sample.samplingPoint.notation"].get<>();
                std::string samplingPointLabel = row["sample.samplingPoint.label"].get<>();
                std::string sampleDateTime = row["sample.sampleDateTime"].get<>();
                std::string determinandLabel = row["determinand.label"].get<>();
                std::string determinandDefinition = row["determinand.definition"].get<>();
                int determinandNotation = row["determinand.notation"].get<int>();
                char resultQualifierNotation = row["resultQualifier.notation"].get<>()[0];
                double result = row["result"].get<double>();
                std::string unitLabel = row["determinand.unit.label"].get<>();
                std::string sampledMaterialTypeLabel = row["sample.sampledMaterialType.label"].get<>();
                bool isComplianceSample = stringToBool(row["sample.isComplianceSample"].get<>());
                std::string samplePurpose = row["sample.purpose.label"].get<>();
                int easting = row["sample.samplingPoint.easting"].get<int>();
                int northing = row["sample.samplingPoint.northing"].get<int>();

                // Create a WaterSample object and add it to the vector
                WaterSample sample(id, samplingPoint, samplingPointNotation, samplingPointLabel, sampleDateTime,
                    determinandLabel, determinandDefinition, determinandNotation, resultQualifierNotation,
                    result, unitLabel, sampledMaterialTypeLabel,
                    isComplianceSample, samplePurpose, easting, northing);
                samples.push_back(sample);

            }
            catch (const std::exception& e) {
                // Log the row that failed to parse
                std::cerr << "Error parsing row: " << e.what() << std::endl;
                return false;
                // throw std::runtime_error("Row parsing error: CSV format invalid.");
            }
        }

        // Insert all data into the database
        return insertBatchIntoDatabase(samples);

    }
    catch (const std::exception& e) {
        // Log the error and return false
        std::cerr << "Error reading CSV file: " << e.what() << std::endl;
        return false;
    }
}
// Insert all WaterSample objects into the database
bool WaterSampleDatabase::insertBatchIntoDatabase(const std::vector<WaterSample>& samples) {
    QSqlQuery query(db);
    query.prepare("INSERT INTO water_samples (id, samplingPoint, samplingPointNotation, samplingPointLabel, "
        "sampleDateTime, determinandLabel, determinandDefinition, determinandNotation, resultQualifierNotation, "
        "result, unitLabel, sampledMaterialTypeLabel, isComplianceSample, "
        "samplePurpose, easting, northing) "
        "VALUES (:id, :samplingPoint, :samplingPointNotation, :samplingPointLabel, :sampleDateTime, "
        ":determinandLabel, :determinandDefinition, :determinandNotation, :resultQualifierNotation, "
        ":result, :unitLabel, :sampledMaterialTypeLabel, :isComplianceSample, "
        ":samplePurpose, :easting, :northing)");

    // Begin a transaction for batch insert
    db.transaction();

    for (const auto& sample : samples) {
        query.bindValue(":id", QString::fromStdString(sample.getId()));
        query.bindValue(":samplingPoint", QString::fromStdString(sample.getSamplingPoint()));
        query.bindValue(":samplingPointNotation", QString::fromStdString(sample.getSamplingPointNotation()));
        query.bindValue(":samplingPointLabel", QString::fromStdString(sample.getSamplingPointLabel()));
        query.bindValue(":sampleDateTime", QString::fromStdString(sample.getSampleDateTime()));
        query.bindValue(":determinandLabel", QString::fromStdString(sample.getDeterminandLabel()));
        query.bindValue(":determinandDefinition", QString::fromStdString(sample.getDeterminandDefinition()));
        query.bindValue(":determinandNotation", sample.getDeterminandNotation());

        char resultQualifier = sample.getResultQualifierNotation();
        if (resultQualifier == '\0' || resultQualifier == '0') { // check for empty value
            query.bindValue(":resultQualifierNotation", QString(""));
        }
        else {
            query.bindValue(":resultQualifierNotation", QString(resultQualifier));
        }

        query.bindValue(":result", sample.getResult());
        query.bindValue(":unitLabel", QString::fromStdString(sample.getUnitLabel()));
        query.bindValue(":sampledMaterialTypeLabel", QString::fromStdString(sample.getSampledMaterialTypeLabel()));
        query.bindValue(":isComplianceSample", sample.getIsComplianceSample());
        query.bindValue(":samplePurpose", QString::fromStdString(sample.getSamplePurpose()));
        query.bindValue(":easting", sample.getEasting());
        query.bindValue(":northing", sample.getNorthing());

        if (!query.exec()) {
            std::cerr << "Failed to insert sample: " << query.lastError().text().toStdString() << std::endl;
            db.rollback();  // Rollback if insertion fails
            return false;
        }
    }

    // Commit the transaction if all insertions succeed
    db.commit();
    return true;
}

QSqlTableModel* WaterSampleDatabase::getTableModel(const QString& determinand) {
    QSqlTableModel* model = new QSqlTableModel();
    model->setTable("water_samples");

    // Search for certain row
    if (!determinand.isEmpty()) {
        model->setFilter(QString("determinandLabel = '%1'").arg(determinand));
    }

    // Load data
    model->select();
    return model;
}

// Change string isComplianceSample to bool
bool WaterSampleDatabase::stringToBool(const std::string& str) {
    if (str == "TRUE" || str == "true") return true;
    if (str == "FALSE" || str == "false") return false;
    throw std::invalid_argument("Invalid boolean value: " + str);
}

QChartView* WaterSampleDatabase::createComplianceChart(const QString& determinand,
    const QString& location,
    const QString& complianceStatus) {
    QChart* chart = new QChart();
    chart->setTitle("Regulatory Compliance Overview");

    QFont titleFont = chart->titleFont();
    titleFont.setPointSize(20);
    titleFont.setBold(true);
    chart->setTitleFont(titleFont);


    // Prepare the SQL query to fetch data
    QString queryStr = R"(
        SELECT
            SUM(CASE WHEN isComplianceSample = 1 THEN 1 ELSE 0 END) AS compliant,
            SUM(CASE WHEN isComplianceSample = 0 THEN 1 ELSE 0 END) AS nonCompliant
        FROM water_samples
        WHERE 1=1
    )";

    if (!determinand.isEmpty() && determinand != "All Pollutants")
        queryStr += " AND determinandLabel = :determinand";
    if (!location.isEmpty() && location != "All Locations")
        queryStr += " AND samplingPointLabel = :location";
    if (complianceStatus == "Compliant Only")
        queryStr += " AND isComplianceSample = 1";
    else if (complianceStatus == "Non-Compliant Only")
        queryStr += " AND isComplianceSample = 0";

    QSqlQuery query;
    query.prepare(queryStr);
    if (!determinand.isEmpty() && determinand != "All Pollutants")
        query.bindValue(":determinand", determinand);
    if (!location.isEmpty() && location != "All Locations")
        query.bindValue(":location", location);

    if (!query.exec()) {
        qDebug() << "Query failed:" << query.lastError();
        delete chart;
        return nullptr;
    }

    int compliantCount = 0;
    int nonCompliantCount = 0;

    if (query.next()) {
        compliantCount = query.value("compliant").toInt();
        nonCompliantCount = query.value("nonCompliant").toInt();
    }

    // Create a pie series for data
    QPieSeries* pieSeries = new QPieSeries();
    if (compliantCount > 0) {
        pieSeries->append("Compliant", compliantCount);
        QPieSlice* compliantSlice = pieSeries->slices().last();
        compliantSlice->setBrush(QColor("#5ba300")); // Green for compliant
        compliantSlice->setLabel(QString("Compliant: %1").arg(compliantCount));
        compliantSlice->setLabelVisible(true);
    }

    if (nonCompliantCount > 0) {
        pieSeries->append("Non-Compliant", nonCompliantCount);
        QPieSlice* nonCompliantSlice = pieSeries->slices().last();
        nonCompliantSlice->setBrush(QColor("#b51963")); // Red for non-compliant
        nonCompliantSlice->setLabel(QString("Non-Compliant: %1").arg(nonCompliantCount));
        nonCompliantSlice->setLabelVisible(true);
    }

    // Handle case where both counts are 0
    if (compliantCount == 0 && nonCompliantCount == 0) {
        QPieSlice* emptySlice = new QPieSlice("No Data", 1);
        emptySlice->setBrush(Qt::lightGray); // Gray for no data
        emptySlice->setLabel("No Data");
        emptySlice->setLabelVisible(true);
        pieSeries->append(emptySlice);
    }

    // Add hover effect to slices
    for (QPieSlice* slice : pieSeries->slices()) {
        QObject::connect(slice, &QPieSlice::hovered, [slice](bool state) {
            slice->setExploded(state); // Toggle exploded state
            slice->setLabelVisible(true);
            });
    }

    chart->addSeries(pieSeries);

    chart->setAnimationOptions(QChart::AllAnimations);

    QChartView* chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    return chartView;
}

QChartView* WaterSampleDatabase::createFCChart(const QString& determinandLabel, const QString& location) {
    QChart* chart = new QChart();
    chart->setTitle("Fluorinated Compound Levels - " + determinandLabel + " at " + location);

    QFont titleFont = chart->titleFont();
    titleFont.setPointSize(20);
    titleFont.setBold(true);
    chart->setTitleFont(titleFont);

    chart->legend()->hide();

    QLineSeries* series = new QLineSeries();
    series->setName("PFAS Levels");

    // Get data
    QSqlQuery query(db);
    query.prepare(R"(
        SELECT sampleDateTime, result 
        FROM water_samples 
        WHERE determinandLabel = :determinandLabel AND samplingPointLabel = :location
        ORDER BY sampleDateTime ASC
    )");
    query.bindValue(":determinandLabel", determinandLabel);
    query.bindValue(":location", location);

    if (!query.exec()) {
        std::cerr << "Query failed: " << query.lastError().text().toStdString() << std::endl;
        delete chart;
        return nullptr;
    }

    QScatterSeries* complianceSeries = new QScatterSeries();
    complianceSeries->setName("Safe Levels");
    complianceSeries->setMarkerShape(QScatterSeries::MarkerShapeCircle);

    QScatterSeries* nonComplianceSeries = new QScatterSeries();
    nonComplianceSeries->setName("Above Threshold");
    nonComplianceSeries->setMarkerShape(QScatterSeries::MarkerShapeRectangle);

    const double safeThreshold = 0.1;
    int pointCount = 0;
    double minResult = std::numeric_limits<double>::max();
    double maxResult = std::numeric_limits<double>::lowest();
    QDateTime minDateTime;
    QDateTime maxDateTime;

    while (query.next()) {
        QDateTime sampleDateTime = QDateTime::fromString(query.value("sampleDateTime").toString(), Qt::ISODate);
        double result = query.value("result").toDouble();

        if (result < minResult) minResult = result;
        if (result > maxResult) maxResult = result;

        if (pointCount == 0) {
            minDateTime = sampleDateTime;
            maxDateTime = sampleDateTime;
        }
        else {
            if (sampleDateTime < minDateTime) minDateTime = sampleDateTime;
            if (sampleDateTime > maxDateTime) maxDateTime = sampleDateTime;
        }

        series->append(sampleDateTime.toMSecsSinceEpoch(), result);

        if (result <= safeThreshold) {
            complianceSeries->append(sampleDateTime.toMSecsSinceEpoch(), result);
        }
        else {
            nonComplianceSeries->append(sampleDateTime.toMSecsSinceEpoch(), result);
        }

        pointCount++;
    }

    if (pointCount > 1) {
        chart->addSeries(series);
    }
    else if (pointCount == 1) {
        complianceSeries->setMarkerSize(10.0);
        nonComplianceSeries->setMarkerSize(10.0);
    }

    chart->addSeries(complianceSeries);
    chart->addSeries(nonComplianceSeries);

    QDateTimeAxis* axisX = new QDateTimeAxis();
    axisX->setFormat("yyyy-MM-dd HH:mm:ss");
    axisX->setTitleText("Date");

    QDateTime rangeStart = minDateTime.addDays(-1);
    QDateTime rangeEnd = maxDateTime.addDays(1);
    axisX->setRange(rangeStart, rangeEnd);

    chart->addAxis(axisX, Qt::AlignBottom);
    complianceSeries->attachAxis(axisX);
    nonComplianceSeries->attachAxis(axisX);
    if (pointCount > 1) {
        series->attachAxis(axisX);
    }

    QValueAxis* axisY = new QValueAxis();
    axisY->setTitleText("PFAS Levels (g/L)");
    axisY->setLabelFormat("%.4f");

    // auto rangePadding
    double rangePadding = 0.0;
    if (maxResult > 10 * minResult) {
        rangePadding = maxResult * 0.2; // 20% upper padding
        axisY->setRange(0.0, maxResult + rangePadding);
    }
    else {
        rangePadding = (maxResult - minResult) * 0.1;
        if (rangePadding == 0) rangePadding = 0.001; // 1% padding for small range
        axisY->setRange(minResult - rangePadding, maxResult + rangePadding);
    }

    chart->addAxis(axisY, Qt::AlignLeft);
    complianceSeries->attachAxis(axisY);
    nonComplianceSeries->attachAxis(axisY);
    if (pointCount > 1) {
        series->attachAxis(axisY);
    }

    // Add a safety threshold line
    if (pointCount > 1) {
        QLineSeries* thresholdLine = new QLineSeries();
        thresholdLine->append(rangeStart.toMSecsSinceEpoch(), safeThreshold);
        thresholdLine->append(rangeEnd.toMSecsSinceEpoch(), safeThreshold);
        thresholdLine->setName("Safety Threshold");
        chart->addSeries(thresholdLine);
        thresholdLine->attachAxis(axisX);
        thresholdLine->attachAxis(axisY);
    }

    // Create QChartView
    QChartView* chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    return chartView;
}

QStringList WaterSampleDatabase::getUniqueEntries(const QString& filter, const QString& type, const QString& complianceStatus) const {
    QStringList results;
    if (!db.isOpen()) {
        qWarning() << "Database not available";
        return results;
    }

    QSqlQuery query;
    QString queryStr;

    if (type == "pollutant") {
        if (filter.isEmpty()) {
            queryStr = "SELECT DISTINCT determinandLabel FROM water_samples";  // Query all pollutants
        }
        else {
            queryStr = "SELECT DISTINCT determinandLabel FROM water_samples WHERE determinandDefinition LIKE '%" + filter + "%'";  // Query pollutants by keyword
        }
    }
    else if (type == "location") {
        if (filter.isEmpty() && complianceStatus.isEmpty()) {
            queryStr = "SELECT DISTINCT samplingPointLabel FROM water_samples";  // Query all locations
        }
        else {
            queryStr = "SELECT DISTINCT samplingPointLabel FROM water_samples WHERE ";
            if (!filter.isEmpty()) {
                queryStr += "determinandLabel = '" + filter + "' ";
            }
            if (!complianceStatus.isEmpty()) {
                if (!filter.isEmpty()) {
                    queryStr += "AND ";
                }
                if (complianceStatus == "Compliant Only") {
                    queryStr += "isComplianceSample = 1";
                }
                else if (complianceStatus == "Non-Compliant Only") {
                    queryStr += "isComplianceSample = 0";
                }
            }
        }
    }

    if (query.prepare(queryStr) && query.exec()) {
        while (query.next()) {
            QString value = query.value(0).toString().trimmed();
            if (!value.isEmpty() && !results.contains(value)) {
                results << value;
            }
        }
    }
    else {
        qWarning() << "Failed to fetch unique entries:" << query.lastError().text();
    }

    // Sort the results alphabetically by first character
    results.sort(Qt::CaseInsensitive);

    return results;
}