#pragma once

#include <string>
#include <vector>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlError>
#include <QDateTime>
#include <QtCharts>
#include "csv.hpp"
#include "sample.hpp"

class WaterSampleDatabase {
public:
    WaterSampleDatabase(const std::string& dbName);
    bool createTable();
    bool readCSV(const std::string& filename);
    // return a SQLTable to show data, defalt: query all data
    QSqlTableModel* getTableModel(const QString& determinand = QString());
    // For different pages
    QChartView* createComplianceChart(const QString& determinand,const QString& location,const QString& complianceStatus);
    QChartView* createFCChart(const QString& determinandLabel, const QString& location);
    QStringList getUniqueEntries(const QString& filter = "", const QString& type = "pollutant", const QString& complianceStatus = "") const;
    
private:
    void clearDatabase();
    bool stringToBool(const std::string& str);
    bool insertBatchIntoDatabase(const std::vector<WaterSample>& samples);
    QSqlDatabase db;
};

