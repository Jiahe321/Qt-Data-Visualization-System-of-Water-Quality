#include "window.hpp"

WaterSampleWindow::WaterSampleWindow(QWidget* parent)
    : QMainWindow(parent), dbFilePath("water_samples.db"), csvFilePath("") {
    // shared db
    db = new WaterSampleDatabase(dbFilePath.toStdString());
    createWidgets();
    arrangeWidgets();
    connectSlots();
    setWindowTitle(tr("Water Quality Visualization Tool"));
}

void WaterSampleWindow::createWidgets() {
    // Initialize main layout
    mainLayout = new QVBoxLayout();

    // Initialize TableView
    tableView = new QTableView();

    // Set up central widget and layout
    centralWidget = new QWidget();

    // Initialize Tab
    tabWidget = new QTabWidget();

    dashboard = new Dashboard(db, this);
    dataPage = new QWidget();
    CD = new ComplianceDashboard(db,this);
    PO = new PollutantOverview(db,this);
    POPsTab = new POPs(db, this);
    ELI = new EnvironmentalLitterIndicators(db, this);
    FC = new FluorinatedCompounds(db, this);
}

void WaterSampleWindow::arrangeWidgets() {
    // Arrange central widget and layout
    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    setDataPage();
    setTabs();
    setStatusBarAndMenuBar();
}

void WaterSampleWindow::setDataPage() {
    // Add TableView to a new tab
    QVBoxLayout* dataLayout = new QVBoxLayout(dataPage);

    // Test search
    QHBoxLayout* searchLayout = new QHBoxLayout();
    QLabel* searchLabel = new QLabel(tr("Search by Determinand Label:"));
    searchInput = new QLineEdit();
    QPushButton* searchButton = new QPushButton(tr("Search"));
    searchLayout->addWidget(searchLabel);
    searchLayout->addWidget(searchInput);
    searchLayout->addWidget(searchButton);

    dataLayout->addLayout(searchLayout);

    // Connect Search Button
    connect(searchButton, &QPushButton::clicked, this, &WaterSampleWindow::searchData);

    // Table
    dataLayout->addWidget(tableView);
}

void WaterSampleWindow::setTabs() {
    tabWidget->addTab(dashboard, tr("Dashboard"));
    tabWidget->addTab(dataPage, tr("Data View"));
    tabWidget->addTab(PO, tr("Pollutant Overview"));
    tabWidget->addTab(POPsTab, tr("Persistent Organic Pollutants (POPs)"));
    tabWidget->addTab(ELI, tr("Environmental Litter Indicators"));
    tabWidget->addTab(FC, tr("Fluorinated Compounds"));
    tabWidget->addTab(CD, tr("Compliance Dashboard"));

    QStringList statusTips = {
        tr("Display a summary of water quality data"),
        tr("View detailed water sample data"),
        tr("Display detailed information on common pollutants."),
        tr("Present data on persistent organic pollutants"
           "due to their long-lasting impact on the environment and health."),
        tr("Check indicators related to environmental litter"),
        tr("Display levels of PFA and other fluorinated compounds,"
           "which are monitored for their environmental persistence."),
        tr("An overview of regulatory compliance across all pollutants,"
           "showing which substances meet or exceed safety standards.")
    };

    connect(tabWidget, &QTabWidget::currentChanged, this, [this, statusTips](int index) {
        if (index >= 0 && index < statusTips.size()) {
            statusBar()->showMessage(statusTips[index]);
        }
        });

    if (!statusTips.isEmpty()) {
        statusBar()->showMessage(statusTips[0]);
    }

    mainLayout->addWidget(tabWidget);
}

void WaterSampleWindow::setStatusBarAndMenuBar() {
    // Creat status bar
    QStatusBar* statusBar = new QStatusBar(this);
    setStatusBar(statusBar);
    statusBar->showMessage(tr("Ready"));

    // Create menu bar
    // File menu
    QMenu* fileMenu = menuBar()->addMenu(tr("File"));
    QAction* loadCSVAction = new QAction(tr("Load CSV"), this);
    loadCSVAction->setShortcut(QKeySequence::Open);
    loadCSVAction->setStatusTip(tr("Load CSV data into the database"));
    connect(loadCSVAction, &QAction::triggered, this, &WaterSampleWindow::loadCSV);
    fileMenu->addAction(loadCSVAction);

    QAction* close = new QAction(tr("Quit"), this);
    close->setShortcut(QKeySequence::Close);
    close->setStatusTip(tr("Quit the application"));
    connect(close, &QAction::triggered, this, &WaterSampleWindow::close);
    fileMenu->addAction(close);

    // Help menu
    QMenu* helpMenu = menuBar()->addMenu(tr("Help"));

    QAction* aboutAction = new QAction(tr("&About"), this);
    aboutAction->setShortcut(QKeySequence::HelpContents);
    aboutAction->setStatusTip(tr("Show information about this application"));
    connect(aboutAction, &QAction::triggered, this, &WaterSampleWindow::about);
    helpMenu->addAction(aboutAction);

    QAction* aboutQtAction = new QAction(tr("About &Qt"), this);
    aboutQtAction->setShortcut(QKeySequence("Ctrl+Q"));
    aboutQtAction->setStatusTip(tr("Show information about the Qt library"));
    connect(aboutQtAction, &QAction::triggered, qApp, &QApplication::aboutQt);
    helpMenu->addAction(aboutQtAction);

}

// Slot implementation for About 
void WaterSampleWindow::about() {
    QMessageBox::about(this, tr("About Water Quality Visualization Tool"),
        tr("This tool is designed to help visualize and analyze UK/EU water quality data.\n"
            "Usage:\n"
            "- Load CSV data into the application\n"
            "- View detailed information on water samples\n"
            "- Analyze compliance with UK/EU water quality standards\n"
            "\n"
            "Developed for better understanding and management of water quality compliance."));
}

void WaterSampleWindow::connectSlots() {
    connect(this, &WaterSampleWindow::dbUpdated, dashboard, &Dashboard::updatePollutants);
    connect(this, &WaterSampleWindow::dbUpdated, PO, &PollutantOverview::addCommonPollutants);
    connect(this, &WaterSampleWindow::dbUpdated, POPsTab, &POPs::updateChart);
    connect(this, &WaterSampleWindow::dbUpdated, ELI, &EnvironmentalLitterIndicators::updateChart);
    connect(this, &WaterSampleWindow::dbUpdated, ELI, &EnvironmentalLitterIndicators::populateDropdowns);
	connect(this, &WaterSampleWindow::dbUpdated, CD, &ComplianceDashboard::updateChart);
    connect(this, &WaterSampleWindow::dbUpdated, CD, &ComplianceDashboard::updateComboBoxes);
    connect(this, &WaterSampleWindow::dbUpdated, FC, &FluorinatedCompounds::updateComboBoxes);
	connect(this, &WaterSampleWindow::dbUpdated, FC, &FluorinatedCompounds::updateChart);
}

void WaterSampleWindow::loadCSV() {
    // Open a file dialog to select the CSV file
    csvFilePath = QFileDialog::getOpenFileName(
        this, tr("Select CSV File"), QString(), tr("CSV Files (*.csv)"));

    if (csvFilePath.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No file selected."));
        return;
    }

    // Database operations
    if (!db->createTable()) {
        QMessageBox::critical(this, tr("Error"), tr("Failed to create or verify the database table."));
        return;
    }

    if (db->readCSV(csvFilePath.toStdString())) {
        tableView->setModel(db->getTableModel());
        statusBar()->showMessage(tr("CSV data loaded successfully."));
        // Inform other pages that the database has been updated
        emit dbUpdated();
    }
    else {
        QMessageBox::critical(this, tr("Error"), tr("Error loading CSV data."));
    }
}

void WaterSampleWindow::searchData() {
    QString filterLabel = searchInput->text(); // Get the input text for filtering
    WaterSampleDatabase db(dbFilePath.toStdString());

    // Get the filtered model
    QSqlTableModel* filteredModel = db.getTableModel(filterLabel);

    if (filteredModel) {
        tableView->setModel(filteredModel); // Update the TableView with the filtered model
        statusBar()->showMessage(filterLabel.isEmpty() ? tr("Showing all data") : tr("Filtered by: ") + filterLabel);
    }
    else {
        QMessageBox::warning(this, tr("Error"), tr("No data found for the given filter."));
    }
}