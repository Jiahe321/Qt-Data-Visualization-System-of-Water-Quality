#pragma once

#include <QColor>

// Helper function to get compliance color
inline QColor getComplianceColor(double value) {
    if (value < 50) return QColor("#5ba300");   // Safe
    if (value < 100) return QColor("orange"); // Caution
    return QColor("#b51963");                     // Exceeding levels
}

inline QString getComplianceStatus(double value) {
    if (value < 50) return "Safe";
    if (value < 100) return "Caution";
    return "Exceeding";
}

inline QString getRiskDescription(double value) {
    if (value < 50) return "Low risk to environment and health.";
    if (value < 100) return "Moderate risk. Take precautions.";
    return "High risk! Immediate action required.";
}
