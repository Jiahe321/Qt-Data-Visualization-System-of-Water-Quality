<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>ComplianceDashboard</name>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="32"/>
        <source>Location:</source>
        <translation>地点：</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="34"/>
        <source>Pollutant:</source>
        <translation>污染物：</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="36"/>
        <source>Compliance:</source>
        <translation>合规：</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="50"/>
        <source>No CSV file selected</source>
        <translation>未选择CSV文件</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="87"/>
        <source>Database not available</source>
        <translation>数据库不可用</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="105"/>
        <source>No data available for the selected filters</source>
        <translation>所选筛选器没有可用数据</translation>
    </message>
</context>
<context>
    <name>Dashboard</name>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="14"/>
        <source>Water Quality Dashboard</source>
        <translation>水质仪表盘</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="18"/>
        <source>Welcome to the Water Quality Dashboard!&lt;br&gt;&lt;br&gt;Use the dropdown menu below to explore different sections:&lt;br&gt;- Pollutants Overview&lt;br&gt;- Persistent Organic Pollutants (POPs)&lt;br&gt;- Environmental Litter Indicators&lt;br&gt;- Fluorinated Compounds&lt;br&gt;- Compliance Dashboard&lt;br&gt;&lt;br&gt;This data is taken from:&lt;a href= &apos;https://environment.data.gov.uk/water-quality/view/download&apos;&gt; Open WIMS Data&lt;/a&gt; &lt;br&gt;&lt;br&gt;You can also navigate with the tabs above for more detailed information about each section.</source>
        <translation>欢迎来到水质仪表板&lt;br&gt;&lt;br&gt;使用下面的下拉菜单探索不同的部分：&lt;br&gt;-污染物概述&lt;br&gt;-持久性有机污染物（POPs）&lt;br&gt;——环境垃圾指标&lt;br&gt;—含氟化合物&lt;br&gt;合规仪表板&lt;br&gt;&lt;br&gt;此数据来自：&lt;a href=&apos;https://environment.data.gov.uk/water-quality/view/download&apos;&gt;打开WIMS数据&lt;/a&gt;&lt;br&gt;&lt;br&gt;您还可以使用上面的选项卡导航，以获取有关每个部分的更多详细信息。</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="35"/>
        <source>Select a page to know more about</source>
        <translation>选择一个页面以了解更多信息</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="36"/>
        <source>Pollutants Overview</source>
        <translation>污染物概述</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="37"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>持久性有机污染物</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="38"/>
        <source>Environmental Litter Indicators</source>
        <translation>环境垃圾指示器</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="39"/>
        <source>Fluorinated Compounds</source>
        <translation>含氟化合物</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="40"/>
        <source>Compliance Dashboard</source>
        <translation>合规仪表板</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="44"/>
        <location filename="../Pages/Dashboard.cpp" line="70"/>
        <location filename="../Pages/Dashboard.cpp" line="140"/>
        <source>Select a page to view its details.</source>
        <translation>选择一个页面以查看其详细信息。</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="50"/>
        <source>CSV not loaded</source>
        <translation>CSV未加载</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="52"/>
        <source>Select a pollutant to view its definition. You need to load CSV file before selecting a pollutant.</source>
        <translation>选择一种污染物以查看其定义。在选择污染物之前，您需要加载CSV文件。</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="73"/>
        <source>Select a pollutant to view its definition. You need to load a CSV file before selecting a pollutant.</source>
        <translation>选择一种污染物以查看其定义。在选择污染物之前，您需要加载CSV文件。</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="80"/>
        <source>Pollutants Overview:&lt;br&gt;&lt;br&gt;Detailed data about common pollutants found in water:&lt;br&gt;- Common Heavy Metals: Lead, Mercury, Cadmium.&lt;br&gt;- Nutrients: Nitrate, Phosphate.&lt;br&gt;- Organic Compounds: Chloroform, etc.&lt;br&gt;&lt;br&gt;Learn about their sources, health impacts, and removal methods:&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/water-research&apos;&gt;More about water pollutants&lt;/a&gt;</source>
        <translation>污染物概述：&lt;br&gt;&lt;br&gt;水中常见污染物的详细数据：&lt;br&gt;-常见重金属：铅、汞、镉&lt;br&gt;-营养成分：硝酸盐、磷酸盐&lt;br&gt;-有机化合物：氯仿等。&lt;br&gt;&lt;br&gt;了解其来源、对健康的影响和去除方法：&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/water-research更多关于水污染物的信息&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="93"/>
        <source>Persistent Organic Pollutants (POPs):&lt;br&gt;&lt;br&gt;Explore data on persistent organic pollutants, such as PCBs and DDTThese chemicals persist in the environment and pose long-term risksto ecosystems and human health:&lt;br&gt;&lt;a href=&apos;https://www.gov.uk/guidance/using-persistent-organic-pollutants-pops&apos;&gt;Learn more about POPs&lt;/a&gt;</source>
        <translation>持久性有机污染物（POPs）：&lt;br&gt;&lt;br&gt;探索多氯联苯和滴滴涕等持久性有机污染的数据。这些化学物质在环境中持续存在，对生态系统和人类健康构成长期风险：&lt;br&gt;&lt;a href=&apos;https://www.gov.uk/guidance/using-persistent-organic-pollutants-pops“&gt;了解更多关于持久性有机污染物的信息&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="104"/>
        <source>Environmental Litter Indicators:

Get insights into litter indicators, including:&lt;br&gt;&lt;br&gt;- Sewage Debris.&lt;br&gt;- Oil Residues.&lt;br&gt;- Microplastics.&lt;br&gt;&lt;br&gt;Understand the impact of litter on aquatic environments:&lt;br&gt;&lt;a href=&apos;https://www.unep.org/topics/ocean-seas-and-coasts/ecosystem-degradation-pollution/plastic-pollution-marine-litter&apos;&gt;More about litter and plastics&lt;/a&gt;</source>
        <translation>环境垃圾指标：

深入了解垃圾指标，包括：&lt;br&gt;&lt;br&gt;-污水碎片。&lt;br&gt;-油渣&lt;br&gt;-微塑料&lt;br&gt;&lt;br&gt;了解垃圾对水生环境的影响：&lt;br&gt;&lt;a href=&apos;https://www.unep.org/topics/ocean-seas-and-coasts/ecosystem-degradation-pollution/plastic-pollution-marine-litter更多关于垃圾和塑料的信息&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="117"/>
        <source>Fluorinated Compounds:&lt;br&gt;&lt;br&gt;This section covers fluorinated compounds, known for their persistence in the environment. Examples include PFAS and related compounds:&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/pfas&apos;&gt;Learn more about PFAS&lt;/a&gt;</source>
        <translation>氟化化合物：&lt;br&gt;&lt;br&gt;本节涵盖了以在环境中的持久性而闻名的氟化化合物。示例包括PFAS和相关化合物：&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/pfas“&gt;了解有关PFAS的更多信息&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="127"/>
        <source>Compliance Dashboard:&lt;br&gt;&lt;br&gt;Review compliance data across all monitored pollutants. See which regions and pollutants meet safety standards and identify areas for improvement:&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/compliance&apos;&gt;Understand compliance requirements&lt;/a&gt;</source>
        <translation>合规仪表板：&lt;br&gt;&lt;br&gt;查看所有监测污染物的合规数据。查看哪些地区和污染物符合安全标准，并确定需要改进的领域：&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/compliance“&gt;了解合规要求&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="204"/>
        <source>No pollutants available for this section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="210"/>
        <source>No pollutants available for this section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="213"/>
        <source>Select a pollutant to view its definition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="231"/>
        <source>Definition: %1</source>
        <translation>定义：%1</translation>
    </message>
</context>
<context>
    <name>WaterSampleWindow</name>
    <message>
        <location filename="../window.cpp" line="10"/>
        <source>Water Quality Visualization Tool</source>
        <translation>水质可视化工具</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="51"/>
        <source>Search by Determinand Label:</source>
        <translation>按行列式标签搜索：</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="53"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="68"/>
        <source>Dashboard</source>
        <translation>仪表板</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="77"/>
        <source>Display a summary of water quality data</source>
        <translation>显示水质数据摘要</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="69"/>
        <source>Data View</source>
        <translation>数据视图</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="78"/>
        <source>View detailed water sample data</source>
        <translation>查看详细的水样数据</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="70"/>
        <source>Pollutant Overview</source>
        <translation>污染物概述</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="79"/>
        <source>Display detailed information on common pollutants.</source>
        <translation>显示常见污染物的详细信息。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="71"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>持久性有机污染物</translation>
    </message>
    <message>
        <source>Present data on persistent organic pollutants
 due to their long-lasting impact on the environment and health.</source>
        <translation type="vanished">关于持久性有机污染物的现有数据
由于其对环境和健康的长期影响。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="72"/>
        <source>Environmental Litter Indicators</source>
        <translation>环境垃圾指示器</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="80"/>
        <source>Present data on persistent organic pollutantsdue to their long-lasting impact on the environment and health.</source>
        <translation>提供关于持久性有机污染物的数据，因为它们对环境和健康有长期影响。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="82"/>
        <source>Check indicators related to environmental litter</source>
        <translation>检查与环境垃圾相关的指标</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="73"/>
        <source>Fluorinated Compounds</source>
        <translation>含氟化合物</translation>
    </message>
    <message>
        <source>Display levels of PFA and other fluorinated compounds,
 which are monitored for their environmental persistence.</source>
        <translation type="vanished">显示PFA和其他氟化化合物的含量，
对其环境持久性进行监测。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="74"/>
        <source>Compliance Dashboard</source>
        <translation>合规仪表板</translation>
    </message>
    <message>
        <source>An overview of regulatory compliance across all pollutants,
 showing which substances meet or exceed safety standards.</source>
        <translation type="vanished">所有污染物的监管合规性概述，
显示哪些物质达到或超过安全标准。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="83"/>
        <source>Display levels of PFA and other fluorinated compounds,which are monitored for their environmental persistence.</source>
        <translation>显示PFA和其他氟化化合物的含量，监测其环境持久性。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="85"/>
        <source>An overview of regulatory compliance across all pollutants,showing which substances meet or exceed safety standards.</source>
        <translation>所有污染物的监管合规性概述，显示哪些物质达到或超过安全标准。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="106"/>
        <source>Ready</source>
        <translation>就绪</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="110"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="111"/>
        <source>Load CSV</source>
        <translation>加载CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="113"/>
        <source>Load CSV data into the database</source>
        <translation>将CSV数据加载到数据库中</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="117"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="119"/>
        <source>Quit the application</source>
        <translation>退出程序</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="124"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="126"/>
        <source>&amp;About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="127"/>
        <source>Show information about this application</source>
        <translation>显示有关此应用程序的信息</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="131"/>
        <source>About &amp;Qt</source>
        <translation>关于Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="132"/>
        <source>Show information about the Qt library</source>
        <translation>显示Qt库的相关信息</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="140"/>
        <source>About Water Quality Visualization Tool</source>
        <translation>关于水质可视化工具</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="141"/>
        <source>This tool is designed to help visualize and analyze UK/EU water quality data.
Usage:
- Load CSV data into the application
- View detailed information on water samples
- Analyze compliance with UK/EU water quality standards

Developed for better understanding and management of water quality compliance.</source>
        <translation>该工具旨在帮助可视化和分析英国/欧盟的水质数据。
用途：
-将CSV数据加载到应用程序中
-查看水样的详细信息
-分析是否符合英国/欧盟水质标准

为更好地理解和管理水质合规性而开发。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="165"/>
        <source>Select CSV File</source>
        <translation>选择CSV文件</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="165"/>
        <source>CSV Files (*.csv)</source>
        <translation>CSV Files (*.csv)</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="168"/>
        <location filename="../window.cpp" line="174"/>
        <location filename="../window.cpp" line="185"/>
        <location filename="../window.cpp" line="201"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="168"/>
        <source>No file selected.</source>
        <translation>未选择文件。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="174"/>
        <source>Failed to create or verify the database table.</source>
        <translation>创建或验证数据库表失败。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="180"/>
        <source>CSV data loaded successfully.</source>
        <translation>CSV数据已成功加载。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="185"/>
        <source>Error loading CSV data.</source>
        <translation>加载CSV数据时出错。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="198"/>
        <source>Showing all data</source>
        <translation>显示所有数据</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="198"/>
        <source>Filtered by: </source>
        <translation>筛选条件： </translation>
    </message>
    <message>
        <location filename="../window.cpp" line="201"/>
        <source>No data found for the given filter.</source>
        <translation>找不到给定筛选器的数据。</translation>
    </message>
</context>
</TS>
