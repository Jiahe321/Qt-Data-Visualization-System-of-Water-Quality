<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>ComplianceDashboard</name>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="32"/>
        <source>Location:</source>
        <translation>地点：</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="34"/>
        <source>Pollutant:</source>
        <translation>污染物：</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="36"/>
        <source>Compliance:</source>
        <translation>合规：</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="50"/>
        <source>No CSV file selected</source>
        <translation>未选择CSV文件</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="87"/>
        <source>Database not available</source>
        <translation>数据库不可用</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="105"/>
        <source>No data available for the selected filters</source>
        <translation>所选筛选器没有可用数据</translation>
    </message>
</context>
<context>
    <name>Dashboard</name>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="13"/>
        <source>Water Quality Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="17"/>
        <source>Welcome to the Water Quality Dashboard!

Use the dropdown menu below to explore different sections:
- Pollutants Overview
- Persistent Organic Pollutants (POPs)
- Environmental Litter Indicators
- Fluorinated Compounds
- Compliance Dashboard

You can also navigate with the tabs above for more detailed information about each section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="30"/>
        <source>Pollutants Overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="31"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation type="unfinished">持久性有机污染物</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="32"/>
        <source>Environmental Litter Indicators</source>
        <translation type="unfinished">环境垃圾指示器</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="33"/>
        <source>Fluorinated Compounds</source>
        <translation type="unfinished">含氟化合物</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="34"/>
        <source>Compliance Dashboard</source>
        <translation type="unfinished">合规仪表板</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="38"/>
        <location filename="../Pages/Dashboard.cpp" line="100"/>
        <source>Select a page to view its details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="44"/>
        <source>CSV not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="46"/>
        <source>Select a pollutant to view its definition. You need to load CSV file before selecting a pollutant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="65"/>
        <source>Pollutants Overview:

Common Heavy Metals: Lead, Mercury, Cadmium
Common Nutrients: Nitrate, Phosphate.
Common Organic Compounds: Chlorofoam

This page display detailed information on common pollutants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="73"/>
        <source>Persistent Organic Pollutants (POPs):

This page display details about persistent organic pollutants.
Present data on persistent organic pollutantsdue to their long-lasting impact on the environment and health.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="80"/>
        <source>Environmental Litter Indicators:

This page display information about environmental litter. Check indicators related to environmental litter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="86"/>
        <source>Fluorinated Compounds:

This page display information about fluorinated compounds,which are monitored for their environmental persistence and influence to health.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="92"/>
        <source>Compliance Dashboard:

Check compliance statistics.
An overview of regulatory compliance across all pollutants,showing which substances meet or exceed safety standards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="165"/>
        <source>Definition: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaterSampleWindow</name>
    <message>
        <location filename="../window.cpp" line="10"/>
        <source>Water Quality Visualization Tool</source>
        <translation>水质可视化工具</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="51"/>
        <source>Search by Determinand Label:</source>
        <translation>按行列式标签搜索：</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="53"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="68"/>
        <source>Dashboard</source>
        <translation>仪表板</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="69"/>
        <source>Display a summary of water quality data</source>
        <translation>显示水质数据摘要</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="71"/>
        <source>Data View</source>
        <translation>数据视图</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="72"/>
        <source>View detailed water sample data</source>
        <translation>查看详细的水样数据</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="74"/>
        <source>Pollutant Overview</source>
        <translation>污染物概述</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="75"/>
        <source>Display detailed information on common pollutants.</source>
        <translation>显示常见污染物的详细信息。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="77"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>持久性有机污染物</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="78"/>
        <source>Present data on persistent organic pollutants
 due to their long-lasting impact on the environment and health.</source>
        <translation>关于持久性有机污染物的现有数据
由于其对环境和健康的长期影响。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="81"/>
        <source>Environmental Litter Indicators</source>
        <translation>环境垃圾指示器</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="82"/>
        <source>Check indicators related to environmental litter</source>
        <translation>检查与环境垃圾相关的指标</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="84"/>
        <source>Fluorinated Compounds</source>
        <translation>含氟化合物</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="85"/>
        <source>Display levels of PFA and other fluorinated compounds,
 which are monitored for their environmental persistence.</source>
        <translation>显示PFA和其他氟化化合物的含量，
对其环境持久性进行监测。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="88"/>
        <source>Compliance Dashboard</source>
        <translation>合规仪表板</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="89"/>
        <source>An overview of regulatory compliance across all pollutants,
 showing which substances meet or exceed safety standards.</source>
        <translation>所有污染物的监管合规性概述，
显示哪些物质达到或超过安全标准。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="100"/>
        <source>Ready</source>
        <translation>就绪</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="104"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="105"/>
        <source>Load CSV</source>
        <translation>加载CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="107"/>
        <source>Load CSV data into the database</source>
        <translation>将CSV数据加载到数据库中</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="111"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="113"/>
        <source>Quit the application</source>
        <translation>退出程序</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="118"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="120"/>
        <source>&amp;About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="121"/>
        <source>Show information about this application</source>
        <translation>显示有关此应用程序的信息</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="125"/>
        <source>About &amp;Qt</source>
        <translation>关于Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="126"/>
        <source>Show information about the Qt library</source>
        <translation>显示Qt库的相关信息</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="134"/>
        <source>About Water Quality Visualization Tool</source>
        <translation>关于水质可视化工具</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="135"/>
        <source>This tool is designed to help visualize and analyze UK/EU water quality data.
Usage:
- Load CSV data into the application
- View detailed information on water samples
- Analyze compliance with UK/EU water quality standards

Developed for better understanding and management of water quality compliance.</source>
        <translation>该工具旨在帮助可视化和分析英国/欧盟的水质数据。
用途：
-将CSV数据加载到应用程序中
-查看水样的详细信息
-分析是否符合英国/欧盟水质标准

为更好地理解和管理水质合规性而开发。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="159"/>
        <source>Select CSV File</source>
        <translation>选择CSV文件</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="159"/>
        <source>CSV Files (*.csv)</source>
        <translation>CSV Files (*.csv)</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="162"/>
        <location filename="../window.cpp" line="168"/>
        <location filename="../window.cpp" line="179"/>
        <location filename="../window.cpp" line="195"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="162"/>
        <source>No file selected.</source>
        <translation>未选择文件。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="168"/>
        <source>Failed to create or verify the database table.</source>
        <translation>创建或验证数据库表失败。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="174"/>
        <source>CSV data loaded successfully.</source>
        <translation>CSV数据已成功加载。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="179"/>
        <source>Error loading CSV data.</source>
        <translation>加载CSV数据时出错。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="192"/>
        <source>Showing all data</source>
        <translation>显示所有数据</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="192"/>
        <source>Filtered by: </source>
        <translation>筛选条件： </translation>
    </message>
    <message>
        <location filename="../window.cpp" line="195"/>
        <source>No data found for the given filter.</source>
        <translation>找不到给定筛选器的数据。</translation>
    </message>
</context>
</TS>
