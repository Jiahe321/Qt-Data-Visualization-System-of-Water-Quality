<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>ComplianceDashboard</name>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="32"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="34"/>
        <source>Pollutant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="36"/>
        <source>Compliance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="41"/>
        <source>No CSV file selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="78"/>
        <source>Database not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="96"/>
        <source>No data available for the selected filters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaterSampleWindow</name>
    <message>
        <location filename="../window.cpp" line="10"/>
        <source>Water Quality Visualization Tool</source>
        <translation>水质可视化工具</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="50"/>
        <source>Search by Determinand Label:</source>
        <translation>按行列式标签搜索：</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="52"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="67"/>
        <source>Data View</source>
        <translation>数据视图</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="68"/>
        <source>View detailed water sample data</source>
        <translation>查看详细的水样数据</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="70"/>
        <source>Pollutant Overview</source>
        <translation>污染物概述</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="71"/>
        <source>Display detailed information on common pollutants.</source>
        <translation>显示常见污染物的详细信息。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="73"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>持久性有机污染物</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="74"/>
        <source>Present data on persistent organic pollutants
 due to their long-lasting impact on the environment and health.</source>
        <translation>关于持久性有机污染物的现有数据
由于其对环境和健康的长期影响。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="77"/>
        <source>Environmental Litter Indicators</source>
        <translation>环境垃圾指示器</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="78"/>
        <source>Check indicators related to environmental litter</source>
        <translation>检查与环境垃圾相关的指标</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="80"/>
        <source>Fluorinated Compounds</source>
        <translation>含氟化合物</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="81"/>
        <source>Display levels of PFA and other fluorinated compounds,
 which are monitored for their environmental persistence.</source>
        <translation>显示PFA和其他氟化化合物的含量，
对其环境持久性进行监测。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="84"/>
        <source>Compliance Dashboard</source>
        <translation>合规仪表板</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="85"/>
        <source>An overview of regulatory compliance across all pollutants,
 showing which substances meet or exceed safety standards.</source>
        <translation>所有污染物的监管合规性概述，
显示哪些物质达到或超过安全标准。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="96"/>
        <source>Ready</source>
        <translation>就绪</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="100"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="101"/>
        <source>Load CSV</source>
        <translation>加载CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="103"/>
        <source>Load CSV data into the database</source>
        <translation>将CSV数据加载到数据库中</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="107"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="109"/>
        <source>Quit the application</source>
        <translation>退出程序</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="114"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="116"/>
        <source>&amp;About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="117"/>
        <source>Show information about this application</source>
        <translation>显示有关此应用程序的信息</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="121"/>
        <source>About &amp;Qt</source>
        <translation>关于Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="122"/>
        <source>Show information about the Qt library</source>
        <translation>显示Qt库的相关信息</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="130"/>
        <source>About Water Quality Visualization Tool</source>
        <translation>关于水质可视化工具</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="131"/>
        <source>This tool is designed to help visualize and analyze UK/EU water quality data.
Usage:
- Load CSV data into the application
- View detailed information on water samples
- Analyze compliance with UK/EU water quality standards

Developed for better understanding and management of water quality compliance.</source>
        <translation>该工具旨在帮助可视化和分析英国/欧盟的水质数据。
用途：
-将CSV数据加载到应用程序中
-查看水样的详细信息
-分析是否符合英国/欧盟水质标准

为更好地理解和管理水质合规性而开发。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="154"/>
        <source>Select CSV File</source>
        <translation>选择CSV文件</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="154"/>
        <source>CSV Files (*.csv)</source>
        <translation>CSV文件（*.CSV）</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="157"/>
        <location filename="../window.cpp" line="163"/>
        <location filename="../window.cpp" line="174"/>
        <location filename="../window.cpp" line="190"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="157"/>
        <source>No file selected.</source>
        <translation>未选择文件。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="163"/>
        <source>Failed to create or verify the database table.</source>
        <translation>创建或验证数据库表失败。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="169"/>
        <source>CSV data loaded successfully.</source>
        <translation>CSV数据已成功加载。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="174"/>
        <source>Error loading CSV data.</source>
        <translation>加载CSV数据时出错。</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="187"/>
        <source>Showing all data</source>
        <translation>显示所有数据</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="187"/>
        <source>Filtered by: </source>
        <translation>筛选条件： </translation>
    </message>
    <message>
        <location filename="../window.cpp" line="190"/>
        <source>No data found for the given filter.</source>
        <translation>找不到给定筛选器的数据。</translation>
    </message>
</context>
</TS>
