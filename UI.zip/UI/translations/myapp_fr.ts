<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR" sourcelanguage="en_US">
<context>
    <name>ComplianceDashboard</name>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="32"/>
        <source>Location:</source>
        <translation>Lieu:</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="34"/>
        <source>Pollutant:</source>
        <translation>Polluant:</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="36"/>
        <source>Compliance:</source>
        <translation>Obéissance:</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="50"/>
        <source>No CSV file selected</source>
        <translation>Aucun fichier CSV sélectionné</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="87"/>
        <source>Database not available</source>
        <translation>Base de données non disponible</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="105"/>
        <source>No data available for the selected filters</source>
        <translation>Aucune donnée disponible pour le filtre sélectionné</translation>
    </message>
</context>
<context>
    <name>Dashboard</name>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="13"/>
        <source>Water Quality Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="17"/>
        <source>Welcome to the Water Quality Dashboard!

Use the dropdown menu below to explore different sections:
- Pollutants Overview
- Persistent Organic Pollutants (POPs)
- Environmental Litter Indicators
- Fluorinated Compounds
- Compliance Dashboard

You can also navigate with the tabs above for more detailed information about each section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="30"/>
        <source>Pollutants Overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="31"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation type="unfinished">Polluants organiques persistants</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="32"/>
        <source>Environmental Litter Indicators</source>
        <translation type="unfinished">Indicateur de déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="33"/>
        <source>Fluorinated Compounds</source>
        <translation type="unfinished">Composés fluorés</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="34"/>
        <source>Compliance Dashboard</source>
        <translation type="unfinished">Tableau de bord de conformité</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="38"/>
        <location filename="../Pages/Dashboard.cpp" line="100"/>
        <source>Select a page to view its details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="44"/>
        <source>CSV not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="46"/>
        <source>Select a pollutant to view its definition. You need to load CSV file before selecting a pollutant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="65"/>
        <source>Pollutants Overview:

Common Heavy Metals: Lead, Mercury, Cadmium
Common Nutrients: Nitrate, Phosphate.
Common Organic Compounds: Chlorofoam

This page display detailed information on common pollutants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="73"/>
        <source>Persistent Organic Pollutants (POPs):

This page display details about persistent organic pollutants.
Present data on persistent organic pollutantsdue to their long-lasting impact on the environment and health.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="80"/>
        <source>Environmental Litter Indicators:

This page display information about environmental litter. Check indicators related to environmental litter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="86"/>
        <source>Fluorinated Compounds:

This page display information about fluorinated compounds,which are monitored for their environmental persistence and influence to health.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="92"/>
        <source>Compliance Dashboard:

Check compliance statistics.
An overview of regulatory compliance across all pollutants,showing which substances meet or exceed safety standards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="165"/>
        <source>Definition: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaterSampleWindow</name>
    <message>
        <location filename="../window.cpp" line="10"/>
        <source>Water Quality Visualization Tool</source>
        <translation>Outil de visualisation de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="51"/>
        <source>Search by Determinand Label:</source>
        <translation>Recherche par TAG déterminant:</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="53"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="68"/>
        <source>Dashboard</source>
        <translation>Tableau de bord</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="69"/>
        <source>Display a summary of water quality data</source>
        <translation>Afficher un résumé des données sur la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="71"/>
        <source>Data View</source>
        <translation>Vue des données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="72"/>
        <source>View detailed water sample data</source>
        <translation>Voir les données détaillées de l&apos;échantillon d&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="74"/>
        <source>Pollutant Overview</source>
        <translation>Résumé des polluants</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="75"/>
        <source>Display detailed information on common pollutants.</source>
        <translation>Affiche des informations détaillées sur les polluants courants.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="77"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>Polluants organiques persistants</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="78"/>
        <source>Present data on persistent organic pollutants
 due to their long-lasting impact on the environment and health.</source>
        <translation>Données disponibles sur les polluants organiques persistants
En raison de ses effets à long terme sur l&apos;environnement et la santé.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="81"/>
        <source>Environmental Litter Indicators</source>
        <translation>Indicateur de déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="82"/>
        <source>Check indicators related to environmental litter</source>
        <translation>Vérifier les indicateurs liés aux déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="84"/>
        <source>Fluorinated Compounds</source>
        <translation>Composés fluorés</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="85"/>
        <source>Display levels of PFA and other fluorinated compounds,
 which are monitored for their environmental persistence.</source>
        <translation>Affichage des teneurs en PFA et autres composés fluorés,
La surveillance de leur persistance environnementale.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="88"/>
        <source>Compliance Dashboard</source>
        <translation>Tableau de bord de conformité</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="89"/>
        <source>An overview of regulatory compliance across all pollutants,
 showing which substances meet or exceed safety standards.</source>
        <translation>Un aperçu de la conformité réglementaire pour tous les contaminants,
Montrer quelles substances répondent ou dépassent les normes de sécurité.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="100"/>
        <source>Ready</source>
        <translation>Prêt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="104"/>
        <source>File</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="105"/>
        <source>Load CSV</source>
        <translation>Chargement du CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="107"/>
        <source>Load CSV data into the database</source>
        <translation>Charger des données CSV dans une base de données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="111"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="113"/>
        <source>Quit the application</source>
        <translation>Quitter l&apos;application</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="118"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="120"/>
        <source>&amp;About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="121"/>
        <source>Show information about this application</source>
        <translation>Afficher des informations sur cette application</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="125"/>
        <source>About &amp;Qt</source>
        <translation>À propos de Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="126"/>
        <source>Show information about the Qt library</source>
        <translation>Afficher les informations relatives à la Bibliothèque Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="134"/>
        <source>About Water Quality Visualization Tool</source>
        <translation>À propos de l&apos;outil de visualisation de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="135"/>
        <source>This tool is designed to help visualize and analyze UK/EU water quality data.
Usage:
- Load CSV data into the application
- View detailed information on water samples
- Analyze compliance with UK/EU water quality standards

Developed for better understanding and management of water quality compliance.</source>
        <translation>Cet outil est conçu pour aider à visualiser et analyser les données sur la qualité de l&apos;eau au Royaume - Uni / UE.
Utilisation:
- charger des données CSV dans l&apos;application
- voir les détails de l&apos;échantillon d&apos;eau
- analyse de la conformité aux normes de qualité de l&apos;eau UK / eu

Développé pour mieux comprendre et gérer la conformité de la qualité de l&apos;eau.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="159"/>
        <source>Select CSV File</source>
        <translation>Sélectionnez le fichier CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="159"/>
        <source>CSV Files (*.csv)</source>
        <translation>CSV Files (*.csv)</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="162"/>
        <location filename="../window.cpp" line="168"/>
        <location filename="../window.cpp" line="179"/>
        <location filename="../window.cpp" line="195"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="162"/>
        <source>No file selected.</source>
        <translation>Aucun fichier sélectionné.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="168"/>
        <source>Failed to create or verify the database table.</source>
        <translation>La création ou la validation de la table de base de données a échoué.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="174"/>
        <source>CSV data loaded successfully.</source>
        <translation>Les données CSV ont été chargées avec succès.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="179"/>
        <source>Error loading CSV data.</source>
        <translation>Erreur lors du chargement des données CSV.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="192"/>
        <source>Showing all data</source>
        <translation>Afficher toutes les données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="192"/>
        <source>Filtered by: </source>
        <translation>Filtrer les critères: </translation>
    </message>
    <message>
        <location filename="../window.cpp" line="195"/>
        <source>No data found for the given filter.</source>
        <translation>Impossible de trouver les données pour le filtre donné.</translation>
    </message>
</context>
</TS>
