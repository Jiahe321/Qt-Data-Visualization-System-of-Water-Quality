<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR" sourcelanguage="en_US">
<context>
    <name>ComplianceDashboard</name>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="32"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="34"/>
        <source>Pollutant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="36"/>
        <source>Compliance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="41"/>
        <source>No CSV file selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="78"/>
        <source>Database not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="96"/>
        <source>No data available for the selected filters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaterSampleWindow</name>
    <message>
        <location filename="../window.cpp" line="10"/>
        <source>Water Quality Visualization Tool</source>
        <translation>Outil de visualisation de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="50"/>
        <source>Search by Determinand Label:</source>
        <translation>Recherche par TAG déterminant:</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="52"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="67"/>
        <source>Data View</source>
        <translation>Vue des données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="68"/>
        <source>View detailed water sample data</source>
        <translation>Voir les données détaillées de l&apos;échantillon d&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="70"/>
        <source>Pollutant Overview</source>
        <translation>Résumé des polluants</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="71"/>
        <source>Display detailed information on common pollutants.</source>
        <translation>Affiche des informations détaillées sur les polluants courants.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="73"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>Polluants organiques persistants</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="74"/>
        <source>Present data on persistent organic pollutants
 due to their long-lasting impact on the environment and health.</source>
        <translation>Données disponibles sur les polluants organiques persistants
En raison de ses effets à long terme sur l&apos;environnement et la santé.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="77"/>
        <source>Environmental Litter Indicators</source>
        <translation>Indicateur de déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="78"/>
        <source>Check indicators related to environmental litter</source>
        <translation>Vérifier les indicateurs liés aux déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="80"/>
        <source>Fluorinated Compounds</source>
        <translation>Composés fluorés</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="81"/>
        <source>Display levels of PFA and other fluorinated compounds,
 which are monitored for their environmental persistence.</source>
        <translation>Affichage des teneurs en PFA et autres composés fluorés,
La surveillance de leur persistance environnementale.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="84"/>
        <source>Compliance Dashboard</source>
        <translation>Tableau de bord de conformité</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="85"/>
        <source>An overview of regulatory compliance across all pollutants,
 showing which substances meet or exceed safety standards.</source>
        <translation>Un aperçu de la conformité réglementaire pour tous les contaminants,
Montrer quelles substances répondent ou dépassent les normes de sécurité.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="96"/>
        <source>Ready</source>
        <translation>Prêt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="100"/>
        <source>File</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="101"/>
        <source>Load CSV</source>
        <translation>Chargement du CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="103"/>
        <source>Load CSV data into the database</source>
        <translation>Charger des données CSV dans une base de données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="107"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="109"/>
        <source>Quit the application</source>
        <translation>Quitter l&apos;application</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="114"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="116"/>
        <source>&amp;About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="117"/>
        <source>Show information about this application</source>
        <translation>Afficher des informations sur cette application</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="121"/>
        <source>About &amp;Qt</source>
        <translation>À propos de Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="122"/>
        <source>Show information about the Qt library</source>
        <translation>Afficher les informations relatives à la Bibliothèque Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="130"/>
        <source>About Water Quality Visualization Tool</source>
        <translation>À propos de l&apos;outil de visualisation de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="131"/>
        <source>This tool is designed to help visualize and analyze UK/EU water quality data.
Usage:
- Load CSV data into the application
- View detailed information on water samples
- Analyze compliance with UK/EU water quality standards

Developed for better understanding and management of water quality compliance.</source>
        <translation>Cet outil est conçu pour aider à visualiser et analyser les données sur la qualité de l&apos;eau au Royaume - Uni / UE.
Utilisation:
- charger des données CSV dans l&apos;application
- voir les détails de l&apos;échantillon d&apos;eau
- analyse de la conformité aux normes de qualité de l&apos;eau UK / eu

Développé pour mieux comprendre et gérer la conformité de la qualité de l&apos;eau.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="154"/>
        <source>Select CSV File</source>
        <translation>Sélectionnez le fichier CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="154"/>
        <source>CSV Files (*.csv)</source>
        <translation>Fichier CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="157"/>
        <location filename="../window.cpp" line="163"/>
        <location filename="../window.cpp" line="174"/>
        <location filename="../window.cpp" line="190"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="157"/>
        <source>No file selected.</source>
        <translation>Aucun fichier sélectionné.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="163"/>
        <source>Failed to create or verify the database table.</source>
        <translation>La création ou la validation de la table de base de données a échoué.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="169"/>
        <source>CSV data loaded successfully.</source>
        <translation>Les données CSV ont été chargées avec succès.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="174"/>
        <source>Error loading CSV data.</source>
        <translation>Erreur lors du chargement des données CSV.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="187"/>
        <source>Showing all data</source>
        <translation>Afficher toutes les données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="187"/>
        <source>Filtered by: </source>
        <translation>Filtrer les critères: </translation>
    </message>
    <message>
        <location filename="../window.cpp" line="190"/>
        <source>No data found for the given filter.</source>
        <translation>Impossible de trouver les données pour le filtre donné.</translation>
    </message>
</context>
</TS>
