<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR" sourcelanguage="en_US">
<context>
    <name>ComplianceDashboard</name>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="32"/>
        <source>Location:</source>
        <translation>Lieu:</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="34"/>
        <source>Pollutant:</source>
        <translation>Polluant:</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="36"/>
        <source>Compliance:</source>
        <translation>Obéissance:</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="50"/>
        <source>No CSV file selected</source>
        <translation>Aucun fichier CSV sélectionné</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="87"/>
        <source>Database not available</source>
        <translation>Base de données non disponible</translation>
    </message>
    <message>
        <location filename="../Pages/ComplianceDashboard.cpp" line="105"/>
        <source>No data available for the selected filters</source>
        <translation>Aucune donnée disponible pour le filtre sélectionné</translation>
    </message>
</context>
<context>
    <name>Dashboard</name>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="14"/>
        <source>Water Quality Dashboard</source>
        <translation>Tableau de bord de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="18"/>
        <source>Welcome to the Water Quality Dashboard!&lt;br&gt;&lt;br&gt;Use the dropdown menu below to explore different sections:&lt;br&gt;- Pollutants Overview&lt;br&gt;- Persistent Organic Pollutants (POPs)&lt;br&gt;- Environmental Litter Indicators&lt;br&gt;- Fluorinated Compounds&lt;br&gt;- Compliance Dashboard&lt;br&gt;&lt;br&gt;This data is taken from:&lt;a href= &apos;https://environment.data.gov.uk/water-quality/view/download&apos;&gt; Open WIMS Data&lt;/a&gt; &lt;br&gt;&lt;br&gt;You can also navigate with the tabs above for more detailed information about each section.</source>
        <translation>Bienvenue au tableau de bord de la qualité de l&apos;eau &lt; BR &gt; &lt; br &gt; utilisez le menu déroulant ci - dessous pour explorer les différentes sections: &lt; br &gt; - Aperçu des polluants &lt; br &gt; - polluants organiques persistants (POP) &lt; br &gt; - indicateurs des déchets environnementaux &lt; br &gt; - composés fluorés &lt; br &gt; tableau de bord de la conformité &lt; br &gt; &lt; br &gt; Ces données proviennent de: &lt; a href = &apos; https://environment.data.gov.uk/water-quality/view/download &apos;&gt; ouvrir les données WIMS &lt; / a &gt; &lt; br &gt; &lt; br &gt; Vous pouvez également naviguer à l&apos;aide des onglets ci - dessus pour obtenir plus de détails sur chaque section.</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="35"/>
        <source>Select a page to know more about</source>
        <translation>Sélectionnez une page pour en savoir plus</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="36"/>
        <source>Pollutants Overview</source>
        <translation>Résumé des polluants</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="37"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>Polluants organiques persistants</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="38"/>
        <source>Environmental Litter Indicators</source>
        <translation>Indicateur de déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="39"/>
        <source>Fluorinated Compounds</source>
        <translation>Composés fluorés</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="40"/>
        <source>Compliance Dashboard</source>
        <translation>Tableau de bord de conformité</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="44"/>
        <location filename="../Pages/Dashboard.cpp" line="70"/>
        <location filename="../Pages/Dashboard.cpp" line="140"/>
        <source>Select a page to view its details.</source>
        <translation>Sélectionnez une page pour voir ses détails.</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="50"/>
        <source>CSV not loaded</source>
        <translation>CSV non chargé</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="52"/>
        <source>Select a pollutant to view its definition. You need to load CSV file before selecting a pollutant.</source>
        <translation>Sélectionnez un polluant pour voir sa définition. Vous devez charger le fichier CSV avant de sélectionner un contaminant.</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="73"/>
        <source>Select a pollutant to view its definition. You need to load a CSV file before selecting a pollutant.</source>
        <translation>Sélectionnez un polluant pour voir sa définition. Vous devez charger le fichier CSV avant de sélectionner un contaminant.</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="80"/>
        <source>Pollutants Overview:&lt;br&gt;&lt;br&gt;Detailed data about common pollutants found in water:&lt;br&gt;- Common Heavy Metals: Lead, Mercury, Cadmium.&lt;br&gt;- Nutrients: Nitrate, Phosphate.&lt;br&gt;- Organic Compounds: Chloroform, etc.&lt;br&gt;&lt;br&gt;Learn about their sources, health impacts, and removal methods:&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/water-research&apos;&gt;More about water pollutants&lt;/a&gt;</source>
        <translation>Résumé des contaminants: &lt; br &gt; &lt; br &gt; données détaillées sur les contaminants courants dans l&apos;eau: &lt; br &gt; - métaux lourds courants: plomb, mercure, Cadmium &lt; br &gt; - composition nutritionnelle: nitrates, phosphates &lt; br &gt; - composés organiques: chloroforme, etc. &lt; br &gt; &lt; br &gt; comprendre leurs sources, leurs effets sur la santé et les méthodes d&apos;élimination: &lt; br &gt; &lt; a href = &apos; https://www.epa.gov/water-research Plus d&apos;informations sur les contaminants de l&apos;eau &lt; / a &gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="93"/>
        <source>Persistent Organic Pollutants (POPs):&lt;br&gt;&lt;br&gt;Explore data on persistent organic pollutants, such as PCBs and DDTThese chemicals persist in the environment and pose long-term risksto ecosystems and human health:&lt;br&gt;&lt;a href=&apos;https://www.gov.uk/guidance/using-persistent-organic-pollutants-pops&apos;&gt;Learn more about POPs&lt;/a&gt;</source>
        <translation>Polluants organiques persistants (POP): &lt; br &gt; &lt; br &gt; Explorer les données sur les polluants organiques persistants tels que les PCB et le DDT ces produits chimiques persistent dans l&apos;environnement et posent des risques à long terme pour les écosystèmes et la santé humaine: &lt; br &gt; &lt; a href = &apos; https://www.gov.uk/guidance/using-persistent-organic-pollutants-pops &gt; en savoir plus sur les polluants organiques persistants &lt; / a &gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="104"/>
        <source>Environmental Litter Indicators:

Get insights into litter indicators, including:&lt;br&gt;&lt;br&gt;- Sewage Debris.&lt;br&gt;- Oil Residues.&lt;br&gt;- Microplastics.&lt;br&gt;&lt;br&gt;Understand the impact of litter on aquatic environments:&lt;br&gt;&lt;a href=&apos;https://www.unep.org/topics/ocean-seas-and-coasts/ecosystem-degradation-pollution/plastic-pollution-marine-litter&apos;&gt;More about litter and plastics&lt;/a&gt;</source>
        <translation>Indicateurs des déchets environnementaux:

Obtenez une compréhension approfondie des indicateurs de déchets, y compris: &lt; br &gt; &lt; br &gt; - Débris d&apos;eaux usées. &lt; br &gt; - scories d&apos;huile. &lt; BR &gt; - microplastiques &lt; BR &gt; &lt; br &gt; comprendre l&apos;impact des déchets sur le milieu aquatique: &lt; br &gt; &lt; a href = &apos; https://www.unep.org/topics/ocean-seas-and-coasts/ecosystem-degradation-pollution/plastic-pollution-marine-litter Plus d&apos;informations sur les déchets et les plastiques &lt; / a &gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="117"/>
        <source>Fluorinated Compounds:&lt;br&gt;&lt;br&gt;This section covers fluorinated compounds, known for their persistence in the environment. Examples include PFAS and related compounds:&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/pfas&apos;&gt;Learn more about PFAS&lt;/a&gt;</source>
        <translation>Composés fluorés: &lt; br &gt; &lt; br &gt; Cette section couvre les composés fluorés connus pour leur persistance dans l&apos;environnement. Exemples: PFAS et composés apparentés: &lt; br &gt; &lt; a href = &apos; https://www.epa.gov/pfas &gt; en savoir plus sur PFAS &lt; / a &gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="127"/>
        <source>Compliance Dashboard:&lt;br&gt;&lt;br&gt;Review compliance data across all monitored pollutants. See which regions and pollutants meet safety standards and identify areas for improvement:&lt;br&gt;&lt;a href=&apos;https://www.epa.gov/compliance&apos;&gt;Understand compliance requirements&lt;/a&gt;</source>
        <translation>Tableau de bord de la conformité: &lt; br &gt; &lt; br &gt; voir les données de conformité pour tous les contaminants surveillés. Voir quelles zones et quels contaminants répondent aux normes de sécurité et identifier les domaines à améliorer: &lt; br &gt; &lt; a href = &apos; https://www.epa.gov/compliance &quot;&gt; comprendre les exigences de conformité &lt; / a &gt;</translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="204"/>
        <source>No pollutants available for this section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="210"/>
        <source>No pollutants available for this section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="213"/>
        <source>Select a pollutant to view its definition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Pages/Dashboard.cpp" line="231"/>
        <source>Definition: %1</source>
        <translation>Définition:%1</translation>
    </message>
</context>
<context>
    <name>WaterSampleWindow</name>
    <message>
        <location filename="../window.cpp" line="10"/>
        <source>Water Quality Visualization Tool</source>
        <translation>Outil de visualisation de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="51"/>
        <source>Search by Determinand Label:</source>
        <translation>Recherche par TAG déterminant:</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="53"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="68"/>
        <source>Dashboard</source>
        <translation>Tableau de bord</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="77"/>
        <source>Display a summary of water quality data</source>
        <translation>Afficher un résumé des données sur la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="69"/>
        <source>Data View</source>
        <translation>Vue des données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="78"/>
        <source>View detailed water sample data</source>
        <translation>Voir les données détaillées de l&apos;échantillon d&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="70"/>
        <source>Pollutant Overview</source>
        <translation>Résumé des polluants</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="79"/>
        <source>Display detailed information on common pollutants.</source>
        <translation>Affiche des informations détaillées sur les polluants courants.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="71"/>
        <source>Persistent Organic Pollutants (POPs)</source>
        <translation>Polluants organiques persistants</translation>
    </message>
    <message>
        <source>Present data on persistent organic pollutants
 due to their long-lasting impact on the environment and health.</source>
        <translation type="vanished">Données disponibles sur les polluants organiques persistants
En raison de ses effets à long terme sur l&apos;environnement et la santé.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="72"/>
        <source>Environmental Litter Indicators</source>
        <translation>Indicateur de déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="80"/>
        <source>Present data on persistent organic pollutantsdue to their long-lasting impact on the environment and health.</source>
        <translation>Présenter des données sur les polluants organiques persistants en raison de leur impact durable sur l&apos;environnement et la santé.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="82"/>
        <source>Check indicators related to environmental litter</source>
        <translation>Vérifier les indicateurs liés aux déchets environnementaux</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="73"/>
        <source>Fluorinated Compounds</source>
        <translation>Composés fluorés</translation>
    </message>
    <message>
        <source>Display levels of PFA and other fluorinated compounds,
 which are monitored for their environmental persistence.</source>
        <translation type="vanished">Affichage des teneurs en PFA et autres composés fluorés,
La surveillance de leur persistance environnementale.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="74"/>
        <source>Compliance Dashboard</source>
        <translation>Tableau de bord de conformité</translation>
    </message>
    <message>
        <source>An overview of regulatory compliance across all pollutants,
 showing which substances meet or exceed safety standards.</source>
        <translation type="vanished">Un aperçu de la conformité réglementaire pour tous les contaminants,
Montrer quelles substances répondent ou dépassent les normes de sécurité.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="83"/>
        <source>Display levels of PFA and other fluorinated compounds,which are monitored for their environmental persistence.</source>
        <translation>Affichage des teneurs en PFA et autres composés fluorés, suivi de leur persistance environnementale.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="85"/>
        <source>An overview of regulatory compliance across all pollutants,showing which substances meet or exceed safety standards.</source>
        <translation>Aperçu de la conformité réglementaire pour tous les contaminants, montrant quelles substances respectent ou dépassent les normes de sécurité.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="106"/>
        <source>Ready</source>
        <translation>Prêt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="110"/>
        <source>File</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="111"/>
        <source>Load CSV</source>
        <translation>Chargement du CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="113"/>
        <source>Load CSV data into the database</source>
        <translation>Charger des données CSV dans une base de données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="117"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="119"/>
        <source>Quit the application</source>
        <translation>Quitter l&apos;application</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="124"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="126"/>
        <source>&amp;About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="127"/>
        <source>Show information about this application</source>
        <translation>Afficher des informations sur cette application</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="131"/>
        <source>About &amp;Qt</source>
        <translation>À propos de Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="132"/>
        <source>Show information about the Qt library</source>
        <translation>Afficher les informations relatives à la Bibliothèque Qt</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="140"/>
        <source>About Water Quality Visualization Tool</source>
        <translation>À propos de l&apos;outil de visualisation de la qualité de l&apos;eau</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="141"/>
        <source>This tool is designed to help visualize and analyze UK/EU water quality data.
Usage:
- Load CSV data into the application
- View detailed information on water samples
- Analyze compliance with UK/EU water quality standards

Developed for better understanding and management of water quality compliance.</source>
        <translation>Cet outil est conçu pour aider à visualiser et analyser les données sur la qualité de l&apos;eau au Royaume - Uni / UE.
Utilisation:
- charger des données CSV dans l&apos;application
- voir les détails de l&apos;échantillon d&apos;eau
- analyse de la conformité aux normes de qualité de l&apos;eau UK / eu

Développé pour mieux comprendre et gérer la conformité de la qualité de l&apos;eau.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="165"/>
        <source>Select CSV File</source>
        <translation>Sélectionnez le fichier CSV</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="165"/>
        <source>CSV Files (*.csv)</source>
        <translation>CSV Files (*.csv)</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="168"/>
        <location filename="../window.cpp" line="174"/>
        <location filename="../window.cpp" line="185"/>
        <location filename="../window.cpp" line="201"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="168"/>
        <source>No file selected.</source>
        <translation>Aucun fichier sélectionné.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="174"/>
        <source>Failed to create or verify the database table.</source>
        <translation>La création ou la validation de la table de base de données a échoué.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="180"/>
        <source>CSV data loaded successfully.</source>
        <translation>Les données CSV ont été chargées avec succès.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="185"/>
        <source>Error loading CSV data.</source>
        <translation>Erreur lors du chargement des données CSV.</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="198"/>
        <source>Showing all data</source>
        <translation>Afficher toutes les données</translation>
    </message>
    <message>
        <location filename="../window.cpp" line="198"/>
        <source>Filtered by: </source>
        <translation>Filtrer les critères: </translation>
    </message>
    <message>
        <location filename="../window.cpp" line="201"/>
        <source>No data found for the given filter.</source>
        <translation>Impossible de trouver les données pour le filtre donné.</translation>
    </message>
</context>
</TS>
