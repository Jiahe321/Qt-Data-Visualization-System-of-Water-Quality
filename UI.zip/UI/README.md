## 2811 Final Coursework

# Team Members
- Jiahe Lin, 201803683  
- Sinjini Sarkar, 201695493  
- Aristaa Singh, 201745878  
- Hannah Ji, 201888788  
- Yusuf Demir, 201718013  

# Project Overview
This application is designed to process, analyze, and visualize UK/EU water quality data.  
The backend has been fully developed and suppose to enable analysis of all CSV documents available on the official website.  
It supports CSV file uploads, visualized and interactive data exploration.

# Main Pages:
1. **Dashboard**: Displays an overview of the application, descriptions of all pages, and details on pollutants (including definitions from the CSV file) after uploading a CSV file.  
2. **Data View**: Shows all data with a search function to get specific pollutants.  
3. **Pollutant Overview**: Displays time trends for common pollutants with detailed data points on hover. Includes a search function to check specific pollutant trends.  
4. **Persistent Organic Pollutants**: Visualizes time trends for persistent organic pollutants with detailed data points on hover.  
5. **Environmental Litter Indicators**: Allows searches for environmental litter distributions by location and pollutant. Users can:
  - Select a specific location and "All pollutants" to view distributions of three types of litter.  
  - Select a specific pollutant and "All locations" to view average distributions across locations.  
6. **Fluorinated Compounds**: Filters all entries containing "perfluoro" from CSV. Users can:  
  - Explore time trends of fluorinated compounds at specific locations based on type.  
  - View information and hazards for specific fluorinated compounds 
  - Use dynamically updated location options based on the selected pollutant to check the time trend of certai1 pollutant in different locations.  
7. **Compliance Dashboard**: Filters pollutants based on location, pollutant type, and compliance status. Displays the proportion of compliance, with dynamically updated location options based on pollutant and compliance status.

# Setup Instructions
1. Unzip the project files and navigate to the root directory.  
2. Create a build directory: `mkdir build`.  
3. Navigate to the build directory: `cd build`.  
4. Run CMake: `cmake ..`.  
5. Compile the application: `make`.  
6. Launch the application: `./myapp`.  

**Note**: Most pages' interactions are unavailable until a CSV file is uploaded. To upload a file, select **File -> Load CSV**. Once the file is loaded, all pages functionalities will be available.

# Dependencies
- Qt6 libraries used: Widgets, LinguistTools, Charts, and Sql.  

# File Structure
- **Pages/**: Contains `cpp` and `hpp` files for different pages.  
- **translation/**: Includes `.ts` and `.qm` files for implementing internationalization (e.g., `myapp_en`, `myapp_zh`, `myapp_fr`).  
- **Root Directory**:
  - `csv.h`: Handles CSV file parsing.  
  - `sample.hpp`: Defines classes for storing data objects.  
  - `database.cpp` and `database.hpp`: Manages database storage and provides methods for data output used by other pages.  
  - `window`: Displays the main window and includes navigation methods for various screens.  
  - `utilities.hpp`: Contains color libraries for marking data.  
  - `main.cpp`: The main program entry point.  

# Known Issues
1. **Environmental Litter Indicators**:  
  - Initially, the system does not filter locations containing all three types of environmental litter. As a result, many locations appear empty.  
  - Test recommendation: First select a pollutant, update the location combo box, and remember the valid locations for later use when retrieving "All pollutants."  

2. **Fluorinated Compounds**:  
  - Due to backend limitations, we cannot provide comprehensive information for every fluorinated compound. Only a few compounds (e.g., PFHxSA, 9Cl-PF3ONS, 5:3 FTCA) are hardcoded with descriptions.  
  - Some fluorinated compounds in the official CSV files have only 1-2 sampling points for certain locations, leading to suboptimal graphs.  
  - Test recommendation: Choose `PFOs` to test the fluorinated compounds page, as it provides more complete data.  

3. **Compliance Dashboard**:  
  - Instead of assessing compliance using pollutant-specific thresholds, we rely on the `isCompliance` column in the CSV files due to the large data volume.  
  - Test recommendation: Choose `1,2,3-TCB` to test the compliance dashboard page, as it includes both compliant and non-compliant data.  
