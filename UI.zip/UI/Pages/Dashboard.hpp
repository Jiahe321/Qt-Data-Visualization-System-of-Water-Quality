#pragma once

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QComboBox>
#include <QPushButton>
#include <QSqlQuery>
#include <QStringList>
#include "database.hpp"

class Dashboard : public QWidget {
    Q_OBJECT

public:
    explicit Dashboard(WaterSampleDatabase* db, QWidget* parent = nullptr);

public slots:
    void updatePollutants();

private slots:
    void onPageSelected(int index);
    void onPollutantSelected(int index); // New slot to handle pollutant selection

private:
    void createWidgets();

    bool CSVLoaded;
    QVBoxLayout* mainLayout;
    QLabel* titleLabel;
    QLabel* pageInfoLabel;
    QLabel* infoDisplayLabel;
    QComboBox* pageSelector;
    QComboBox* pollutantSelector;
    QLabel* csvStatusLabel;

    WaterSampleDatabase* db;
    bool isCSVLoaded;
};

