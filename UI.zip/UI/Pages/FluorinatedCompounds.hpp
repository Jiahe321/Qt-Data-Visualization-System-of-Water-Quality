#pragma once

#include <QWidget>
#include <QComboBox>
#include <QDateEdit>
#include <QVBoxLayout>
#include <QLabel>
#include <QChartView>
#include <QScrollArea>
#include "database.hpp"

class FluorinatedCompounds : public QWidget {
    Q_OBJECT

public:
    FluorinatedCompounds(WaterSampleDatabase* database, QWidget* parent = nullptr);

public slots:
    void updateChart();
    void updateComboBoxes();
    void showHazardInfo(const QString& compound);
    void updateLocations(const QString& compound);

private:
    WaterSampleDatabase* db;
    QLabel* infoLabel;
    QChartView* chartView;
    QComboBox* compoundComboBox;
    QComboBox* locationComboBox;
    QScrollArea* hazardScrollArea;
    QLabel* hazardLabel;
    void connectSlots();
    void onCompoundChanged(int index);
    void onLocationChanged(int index);
};
