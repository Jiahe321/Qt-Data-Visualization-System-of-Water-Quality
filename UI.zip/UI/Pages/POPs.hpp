#pragma once

#include <QWidget>
#include <QChartView>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include "database.hpp"

class POPs : public QWidget {
    Q_OBJECT

public:
    POPs(WaterSampleDatabase* database, QWidget* parent = nullptr);

public slots:
    void updateChart();
    void onPointHovered(const QPointF& point, bool state);

private:
    WaterSampleDatabase* db;                // Database pointer
    QLabel* infoLabel;                      // Label for messages
    QGridLayout* gridLayout;                  // Grid layout for the charts
    QVector<QString> pollutantNames;          // List of POPs names
    QVector<QChartView*> chartViews;          // Store chart views to allow updates
    QScrollArea* scrollArea;                  // Scroll area for the charts

    QChartView* createChart(const QString& pollutantName, const QVector<QPair<QDateTime, double>>& dataPoints);
    QVector<QPair<QDateTime, double>> getDataPoints(const QString& pollutantName);

    // Helper methods for compliance and risk descriptions
    QString getComplianceStatus(double value) const;
    QString getRiskDescription(double value) const;
};