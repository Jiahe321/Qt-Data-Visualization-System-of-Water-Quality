#include "GeographicalHotspots.hpp"
#include <QVBoxLayout>
#include <QDebug>
GeographicalHotspots::GeographicalHotspots(WaterSampleDatabase* database, QWidget* parent)
    : QWidget(parent), db(database) {

    QVBoxLayout* layout = new QVBoxLayout(this);

    // ���ص�ͼ
    loadMap();

    setLayout(layout);
}

// ���� QML �ļ���չʾ��ͼ
void GeographicalHotspots::loadMap() {
    return;
}
