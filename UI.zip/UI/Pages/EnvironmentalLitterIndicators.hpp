#pragma once

#include <QWidget>
#include <QLabel>
#include <QtCharts>
#include "database.hpp"

class EnvironmentalLitterIndicators : public QWidget {
    Q_OBJECT

public:
    EnvironmentalLitterIndicators(WaterSampleDatabase* database, QWidget* parent = nullptr);

public slots:
    void updateChart();
    void populateDropdowns(); // Populate dropdown options

private:
    WaterSampleDatabase* db;
    QLabel* infoLabel;
    QChartView* chartView;
    QComboBox* locationDropdown;   // Dropdown for locations
    QComboBox* litterTypeDropdown; // Dropdown for litter types
    QString selectedLocation;    // Current selected location
    QString selectedLitterType; // Current selected litter type
    QScrollArea* scrollArea; // Scroll area for the chart view


    QVector<QPair<QString, double>> getLitterData(const QString& location, const QString& litterType); // Fetch data

    // Mapping determinantDefinition to Label
    QMap<QString, QString> litterTypeMap = {
        {"All Litter Types", ""},
        {"Bathing Water Profile : Other Litter (incl. plastics)", "BWP - O.L."},
        {"Sewage debris", "SewageDebris"},
        {"Tarry residues", "TarryResidus"}
        // Add more mappings as needed
    };


private slots:
    void onFilterChanged();
    void onPointHovered(const QPointF& point, bool state); // Slot for point hover
    void onPointClicked(const QPointF& point);            // Slot for point click
    void onLitterTypeChanged();// Slot for litter type change, update location 

protected:
    void resizeEvent(QResizeEvent* event) override;


};