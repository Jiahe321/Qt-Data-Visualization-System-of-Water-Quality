#pragma once

#include <QWidget>

#include <QtCharts>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QVector>
#include <QPair>
#include <QDateTime>
#include "database.hpp"

class PollutantOverview : public QWidget {
    Q_OBJECT
public:
    PollutantOverview(WaterSampleDatabase* database, QWidget* parent = nullptr);

public slots:
    void updateChart();  // No arguments to match the signal
    void addCommonPollutants();  // Add default charts for common pollutants
    void onSearchButtonClicked();
    void onPointHovered(const QPointF& point, bool state);
    void onPointClicked(const QPointF& point);
    void showPopup(const QString& category, const QString& pollutant, const QPointF& point);
    void showSectionPopup(const QString& category);

private:
    WaterSampleDatabase* db;
    QLabel* infoLabel;
    QLabel* emptySearchLabel;
    QLineEdit* searchInput;
    QPushButton* searchButton;
    QChartView* searchedChartView;
    QVBoxLayout* commonPollutantsLayout;
    QString lastSearchQuery;  // Store the last searched pollutant

    QVector<QPair<QDateTime, double>> getDataPoints(const QString& determinand);
    QString getComplianceStatus(double value) const;
    QString getRiskDescription(double value) const;
    void clearCommonPollutants(); // Clear existing common pollutants 
};