﻿#include "PollutantOverview.hpp"
#include "utilities.hpp"

PollutantOverview::PollutantOverview(WaterSampleDatabase* database, QWidget* parent)
    : QWidget(parent), db(database), searchedChartView(nullptr), commonPollutantsLayout(nullptr) {
    QVBoxLayout* mainLayout = new QVBoxLayout(this);

    // Info Label (persistent top text)
    QLabel* topInfoLabel = new QLabel("Search for a pollutant chart or view common pollutants below.", this);
    topInfoLabel->setStyleSheet("font-size: 14px;");
    mainLayout->addWidget(topInfoLabel);

    // Scroll Area to contain all content
    QScrollArea* scrollArea = new QScrollArea(this);
    QWidget* scrollContent = new QWidget();
    QVBoxLayout* scrollContentLayout = new QVBoxLayout(scrollContent);

    // Search Bar
    QHBoxLayout* searchLayout = new QHBoxLayout();
    QLabel* searchLabel = new QLabel("Search Pollutant:");
    searchInput = new QLineEdit(this);
    searchButton = new QPushButton("Search");
    searchInput->setEnabled(false);  // Disable search bar until CSV file is loaded
    searchButton->setEnabled(false);
    searchLayout->addWidget(searchLabel);
    searchLayout->addWidget(searchInput);
    searchLayout->addWidget(searchButton);
    scrollContentLayout->addLayout(searchLayout);

    // Add a label for dynamic search-related messages
    emptySearchLabel = new QLabel(this);
    emptySearchLabel->setVisible(false);  // Hidden by default
    scrollContentLayout->addWidget(emptySearchLabel);

    connect(searchButton, &QPushButton::clicked, this, &PollutantOverview::onSearchButtonClicked);
    // Connect the search input's returnPressed signal to the search functionality
    connect(searchInput, &QLineEdit::returnPressed, this, &PollutantOverview::onSearchButtonClicked);


    /*
    // Compliance Legend
    QHBoxLayout* legendLayout = new QHBoxLayout();
    QLabel* safeLabel = new QLabel("Safe");
    safeLabel->setStyleSheet("color: #5ba300; font-weight: bold;");

    QLabel* cautionLabel = new QLabel("Caution");
    cautionLabel->setStyleSheet("color: orange; font-weight: bold;");

    QLabel* exceedingLabel = new QLabel("Exceeding Levels");
    exceedingLabel->setStyleSheet("color: #b51963; font-weight: bold;");

    legendLayout->addWidget(safeLabel);
    legendLayout->addWidget(cautionLabel);
    legendLayout->addWidget(exceedingLabel);
    legendLayout->addStretch();

    scrollContentLayout->addLayout(legendLayout);
    */

    // Common pollutants section
    QLabel* commonPollutantsTitle = new QLabel("Common Pollutants:");
    commonPollutantsTitle->setStyleSheet("font-weight: bold; font-size: 16px;");
    scrollContentLayout->addWidget(commonPollutantsTitle);

    commonPollutantsLayout = new QVBoxLayout();
    scrollContentLayout->addLayout(commonPollutantsLayout);

    // Add the scrollable content to the scroll area
    scrollContent->setLayout(scrollContentLayout);
    scrollArea->setWidget(scrollContent);
    scrollArea->setWidgetResizable(true);

    // Add the scroll area to the main layout
    mainLayout->addWidget(scrollArea);
}

void PollutantOverview::onSearchButtonClicked() {
    lastSearchQuery = searchInput->text().trimmed();
    updateChart();
}

void PollutantOverview::onPointHovered(const QPointF& point, bool state) {
    if (state) {  // When hovering starts
        QString details = QString("Pollutant Level: %1\nCompliance Status: %2\nRisk: %3")
            .arg(point.y())
            .arg(getComplianceStatus(point.y()))
            .arg(getRiskDescription(point.y()));
        QToolTip::showText(QCursor::pos(), details, this);
    }
    else {
        QToolTip::hideText();  // Hide tooltip when hover ends
    }
}

void PollutantOverview::onPointClicked(const QPointF& point) {
    QString details = QString(
        "Pollutant Level: %1\nCompliance Status: %2\nRisk: %3\nThresholds:\nSafe: < 50\nCaution: 50-100\nExceeding: > 100")
        .arg(point.y())
        .arg(getComplianceStatus(point.y()))
        .arg(getRiskDescription(point.y()));
    QMessageBox::information(this, "Pollutant Details", details);
}

void PollutantOverview::showPopup(const QString& category, const QString& pollutant, const QPointF& point) {
    QString details = QString(
        "Category: %1\n"
        "Pollutant: %2\n\n"
        "Data Point:\n"
        "- Level: %3\n"
        "- Date: %4\n\n"
        "Thresholds:\n"
        "- Safe: < 50\n"
        "- Caution: 50-100\n"
        "- Exceeding: > 100\n\n"
        "Description:\nThis pollutant is monitored due to its impact on health and the environment."
    ).arg(category)
        .arg(pollutant)
        .arg(point.y())
        .arg(QDateTime::fromMSecsSinceEpoch(point.x()).toString("yyyy-MM-dd"));

    QMessageBox::information(this, QString("%1 Details").arg(category), details);
}

void PollutantOverview::showSectionPopup(const QString& category) {
    QString message = QString(
        "For the %1 section.\n\n"
        "This section includes the following pollutants:\n"
    ).arg(category);

    if (category == "Heavy Metals") {
        message += "- Lead (Pb)\n- Mercury (Hg)\n- Cadmium (Cd)\n- Chromium (Cr)";
    }
    else if (category == "Nutrients") {
        message += "- Nitrate (NO3-)\n- Phosphate (PO4³-)";
    }
    else if (category == "Volatile Organic Compounds") {
        message += "- Chloroform\n- 1,1,2-Trichloroethane";
    }
    else {
        message += "No pollutants available.";
    }

    QMessageBox::information(this, QString("%1 Section Details").arg(category), message);
}

void PollutantOverview::updateChart() {
    // Clear the previous message in emptySearchLabel
    emptySearchLabel->clear();
    emptySearchLabel->setVisible(false);

    if (lastSearchQuery.isEmpty()) {
        emptySearchLabel->setText("Please enter a pollutant name.");
        emptySearchLabel->show();
        return;
    }

    // Validate the database pointer
    if (!db) {
        emptySearchLabel->setText("Database is not initialized.");
        emptySearchLabel->show();
        qDebug() << "Database pointer is null!";
        return;
    }

    // Remove old chart
    if (searchedChartView) {
        layout()->removeWidget(searchedChartView);
        delete searchedChartView;
        searchedChartView = nullptr;
    }

    // Fetch data
    QVector<QPair<QDateTime, double>> dataPoints = getDataPoints(lastSearchQuery);
    if (dataPoints.isEmpty()) {
        emptySearchLabel->setText("No data available for the selected pollutant.");
        emptySearchLabel->show();
        return;
    }

    // Sort points by timestamp
    std::sort(dataPoints.begin(), dataPoints.end(), [](const auto& a, const auto& b) {
        return a.first < b.first;
        });

    // Create line series for the lines
    QLineSeries* safeSeries = new QLineSeries();
    safeSeries->setName("Safe");
    safeSeries->setColor(QColor("#5ba300"));

    QLineSeries* cautionSeries = new QLineSeries();
    cautionSeries->setName("Caution");
    cautionSeries->setColor(QColor("orange"));

    QLineSeries* exceedingSeries = new QLineSeries();
    exceedingSeries->setName("Exceeding Levels");
    exceedingSeries->setColor(QColor("#b51963"));

    // Create scatter series for larger points
    QScatterSeries* safePoints = new QScatterSeries();
    safePoints->setColor(QColor("#5ba300"));
    safePoints->setMarkerSize(7.0);

    QScatterSeries* cautionPoints = new QScatterSeries();
    cautionPoints->setColor(QColor("orange"));
    cautionPoints->setMarkerSize(7.0);

    QScatterSeries* exceedingPoints = new QScatterSeries();
    exceedingPoints->setColor(QColor("#b51963"));
    exceedingPoints->setMarkerSize(7.0);



    double minValue = std::numeric_limits<double>::max();
    double maxValue = std::numeric_limits<double>::lowest();

    // Populate the series
    for (const auto& point : dataPoints) {
        double value = point.second;
        minValue = qMin(minValue, value);
        maxValue = qMax(maxValue, value);

        // Append point to the correct series
        QColor color = getComplianceColor(value);
        if (color == QColor("#5ba300")) {
            safeSeries->append(point.first.toMSecsSinceEpoch(), value);
            safePoints->append(point.first.toMSecsSinceEpoch(), value);
        }
        else if (color == QColor("orange")) {
            cautionSeries->append(point.first.toMSecsSinceEpoch(), value);
            cautionPoints->append(point.first.toMSecsSinceEpoch(), value);
        }
        else {
            exceedingSeries->append(point.first.toMSecsSinceEpoch(), value);
            exceedingPoints->append(point.first.toMSecsSinceEpoch(), value);
        }
    }

    // Add padding to the Y-axis
    double padding = (maxValue - minValue) * 0.1;
    minValue = qMax(0.0, minValue - padding);
    maxValue += padding;

    // Create chart
    QFont titleFont;
    titleFont.setBold(true);
    titleFont.setPointSize(20);

    QChart* chart = new QChart();
    chart->addSeries(safeSeries);
    chart->addSeries(cautionSeries);
    chart->addSeries(exceedingSeries);
    chart->addSeries(safePoints);
    chart->addSeries(cautionPoints);
    chart->addSeries(exceedingPoints);
    chart->setTitleFont(titleFont);
    chart->setTitle(QString("Trend for %1").arg(lastSearchQuery));
    chart->legend()->setAlignment(Qt::AlignTop);
    chart->legend()->markers(safePoints).first()->setVisible(false);
    chart->legend()->markers(cautionPoints).first()->setVisible(false);
    chart->legend()->markers(exceedingPoints).first()->setVisible(false);

    // X-axis
    QDateTimeAxis* axisX = new QDateTimeAxis();
    axisX->setFormat("yyyy-MM-dd HH:mm");
    axisX->setTitleText("Sample Date Time");
    axisX->setLabelsAngle(-45);
    chart->addAxis(axisX, Qt::AlignBottom);
    safeSeries->attachAxis(axisX);
    cautionSeries->attachAxis(axisX);
    exceedingSeries->attachAxis(axisX);
    safePoints->attachAxis(axisX);
    cautionPoints->attachAxis(axisX);
    exceedingPoints->attachAxis(axisX);

    // Y-axis
    QValueAxis* axisY = new QValueAxis();
    axisY->setTitleText("Pollutant Levels");
    axisY->setRange(minValue, maxValue);
    chart->addAxis(axisY, Qt::AlignLeft);
    safeSeries->attachAxis(axisY);
    cautionSeries->attachAxis(axisY);
    exceedingSeries->attachAxis(axisY);
    safePoints->attachAxis(axisY);
    cautionPoints->attachAxis(axisY);
    exceedingPoints->attachAxis(axisY);

    // Add interactivity for hover and click on each series
    connect(safeSeries, &QLineSeries::hovered, this, &PollutantOverview::onPointHovered);
    connect(cautionSeries, &QLineSeries::hovered, this, &PollutantOverview::onPointHovered);
    connect(exceedingSeries, &QLineSeries::hovered, this, &PollutantOverview::onPointHovered);

    // Display chart
    searchedChartView = new QChartView(chart);
    searchedChartView->setRenderHint(QPainter::Antialiasing);

    // Adjust height and policy to prevent clipping
    searchedChartView->setMinimumSize(500, 500); // Adjust to 400px or more
    searchedChartView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);

    // Ensure scrollContentLayout is retrieved correctly
    QScrollArea* scrollArea = findChild<QScrollArea*>();
    if (scrollArea) {
        QWidget* scrollContent = scrollArea->widget();
        if (scrollContent) {
            QVBoxLayout* scrollContentLayout = qobject_cast<QVBoxLayout*>(scrollContent->layout());
            if (scrollContentLayout) {
                scrollContentLayout->insertWidget(2, searchedChartView);
                emptySearchLabel->hide();
            }
        }
    }
}


void PollutantOverview::addCommonPollutants() {

    searchInput->setEnabled(true);
    searchButton->setEnabled(true);
    clearCommonPollutants();

    // Define pollutant categories
    QMap<QString, QStringList> pollutantCategories = {
        {"Heavy Metals", {"Lead - as Pb", "Mercury - Hg", "Cadmium - Cd", "Chromium - Cr"}},
        {"Nutrients", {"Nitrate-N", "Phosphate"}},
        {"Volatile Organic Compounds", {"Chloroform", "112TCEthan"}}
    };

    // Iterate over each category
    for (const QString& category : pollutantCategories.keys()) {
        // Add a subheading with a button overlay
        QPushButton* categoryButton = new QPushButton(category + " (Click for details)");
        categoryButton->setStyleSheet("font-weight: bold; font-size: 14px; text-align: left;");
        categoryButton->setFlat(true);  // Make the button look like a label
        commonPollutantsLayout->addWidget(categoryButton);

        // Connect the button to show the popup
        connect(categoryButton, &QPushButton::clicked, this, [=]() {
            showSectionPopup(category);
            });

        // Create a vertical layout for the pollutants in this category
        QVBoxLayout* verticalLayout = new QVBoxLayout();

        for (const QString& pollutant : pollutantCategories[category]) {
            QVector<QPair<QDateTime, double>> dataPoints = getDataPoints(pollutant);
            if (dataPoints.isEmpty()) continue;

            QMap<QString, int> downsamplingRates = {
                {"Lead - as Pb", 10},
                {"Nitrate-N", 50},
                {"Cadmium - Cd", 10},
                {"Phosphate", 10},
                {"Chloroform", 5}
            };

            if (downsamplingRates.contains(pollutant)) {
                int samplingRate = downsamplingRates[pollutant];
                QVector<QPair<QDateTime, double>> downsampledPoints;
                for (int i = 0; i < dataPoints.size(); i += samplingRate) {
                    downsampledPoints.append(dataPoints[i]);
                }
                dataPoints = downsampledPoints; // Replace with downsampled data
            }




            // Sort points by timestamp
            std::sort(dataPoints.begin(), dataPoints.end(), [](const auto& a, const auto& b) {
                return a.first < b.first;
                });

            // Create line series for the lines
            QLineSeries* safeSeries = new QLineSeries();
            safeSeries->setName("Safe");
            safeSeries->setColor(QColor("#5ba300"));

            QLineSeries* cautionSeries = new QLineSeries();
            cautionSeries->setName("Caution");
            cautionSeries->setColor(QColor("orange"));

            QLineSeries* exceedingSeries = new QLineSeries();
            exceedingSeries->setName("Exceeding Levels");
            exceedingSeries->setColor(QColor("#b51963"));

            // Create scatter series for larger points
            QScatterSeries* safePoints = new QScatterSeries();
            safePoints->setColor(QColor("#5ba300"));
            safePoints->setMarkerSize(7.0);

            QScatterSeries* cautionPoints = new QScatterSeries();
            cautionPoints->setColor(QColor("orange"));
            cautionPoints->setMarkerSize(7.0);

            QScatterSeries* exceedingPoints = new QScatterSeries();
            exceedingPoints->setColor(QColor("#b51963"));
            exceedingPoints->setMarkerSize(7.0);

            for (const auto& point : dataPoints) {
                QColor color = getComplianceColor(point.second);
                if (color == QColor("#5ba300")) {
                    safeSeries->append(point.first.toMSecsSinceEpoch(), point.second);
                    safePoints->append(point.first.toMSecsSinceEpoch(), point.second);
                }
                else if (color == QColor("orange")) {
                    cautionSeries->append(point.first.toMSecsSinceEpoch(), point.second);
                    cautionPoints->append(point.first.toMSecsSinceEpoch(), point.second);
                }
                else {
                    exceedingSeries->append(point.first.toMSecsSinceEpoch(), point.second);
                    exceedingPoints->append(point.first.toMSecsSinceEpoch(), point.second);
                }
            }

            QFont titleFont;
            titleFont.setBold(true);      // Make the font bold
            titleFont.setPointSize(20);   // Set the font size (e.g., 14)

            // Create chart
            QChart* chart = new QChart();
            chart->addSeries(safeSeries);
            chart->addSeries(cautionSeries);
            chart->addSeries(exceedingSeries);
            chart->addSeries(safePoints);
            chart->addSeries(cautionPoints);
            chart->addSeries(exceedingPoints);
            chart->setTitleFont(titleFont);
            chart->setTitle(QString("Trend for %1").arg(pollutant));
            chart->legend()->setVisible(true);
            chart->legend()->setAlignment(Qt::AlignTop);
            chart->legend()->markers(safePoints).first()->setVisible(false);
            chart->legend()->markers(cautionPoints).first()->setVisible(false);
            chart->legend()->markers(exceedingPoints).first()->setVisible(false);

            // X-axis
            QDateTimeAxis* axisX = new QDateTimeAxis();
            axisX->setFormat("yyyy-MM-dd HH:mm");  // Include time in the format
            axisX->setTitleText("Sample Date Time");  // Update axis title if needed
            axisX->setLabelsAngle(-45);
            chart->addAxis(axisX, Qt::AlignBottom);
            safeSeries->attachAxis(axisX);
            cautionSeries->attachAxis(axisX);
            exceedingSeries->attachAxis(axisX);
            safePoints->attachAxis(axisX);
            cautionPoints->attachAxis(axisX);
            exceedingPoints->attachAxis(axisX);

            // Y-axis
            QValueAxis* axisY = new QValueAxis();
            axisY->setTitleText("Pollutant Level");
            chart->addAxis(axisY, Qt::AlignLeft);
            safeSeries->attachAxis(axisY);
            cautionSeries->attachAxis(axisY);
            exceedingSeries->attachAxis(axisY);
            safePoints->attachAxis(axisY);
            cautionPoints->attachAxis(axisY);
            exceedingPoints->attachAxis(axisY);

            // Add hover functionality for scatter points
            connect(safePoints, &QScatterSeries::hovered, this, &PollutantOverview::onPointHovered);
            connect(cautionPoints, &QScatterSeries::hovered, this, &PollutantOverview::onPointHovered);
            connect(exceedingPoints, &QScatterSeries::hovered, this, &PollutantOverview::onPointHovered);

            // Create chart view
            QChartView* chartView = new QChartView(chart);
            chartView->setRenderHint(QPainter::Antialiasing);
            chartView->setMinimumSize(500, 500);

            // Connect series click signal to show popup
            connect(safeSeries, &QLineSeries::clicked, this, [=](const QPointF& point) {
                showPopup(category, pollutant, point);
                });
            connect(cautionSeries, &QLineSeries::clicked, this, [=](const QPointF& point) {
                showPopup(category, pollutant, point);
                });
            connect(exceedingSeries, &QLineSeries::clicked, this, [=](const QPointF& point) {
                showPopup(category, pollutant, point);
                });

            // Add chart to the vertical layout
            verticalLayout->addWidget(chartView);
        }

        // Add grid layout to the common pollutants layout
        commonPollutantsLayout->addLayout(verticalLayout);
    }
}




void PollutantOverview::clearCommonPollutants() {
    QLayoutItem* child;
    while ((child = commonPollutantsLayout->takeAt(0)) != nullptr) {
        delete child->widget();
        delete child;
    }
}

QString PollutantOverview::getComplianceStatus(double value) const {
    if (value < 50) return "Safe";
    if (value < 100) return "Caution";
    return "Exceeding";
}

QString PollutantOverview::getRiskDescription(double value) const {
    if (value < 50) return "Low risk to environment and health.";
    if (value < 100) return "Moderate risk. Take precautions.";
    return "High risk! Immediate action required.";
}

QVector<QPair<QDateTime, double>> PollutantOverview::getDataPoints(const QString& determinand) {
    QVector<QPair<QDateTime, double>> points;

    QSqlQuery query;
    query.prepare("SELECT sampleDateTime, result FROM water_samples WHERE determinandLabel = :determinand");
    query.bindValue(":determinand", determinand);

    if (!query.exec()) {
        qDebug() << "Database query failed:" << query.lastError().text();
        return points;
    }

    while (query.next()) {
        QDateTime dateTime = QDateTime::fromString(query.value("sampleDateTime").toString(), Qt::ISODate);
        if (!dateTime.isValid()) continue;

        double result = query.value("result").toDouble();
        points.append(qMakePair(dateTime, result));
    }

    return points;
}
