#pragma once

#include <QWidget>
#include "database.hpp"

class ComplianceDashboard : public QWidget {
    Q_OBJECT

public:
    ComplianceDashboard(WaterSampleDatabase* database, QWidget* parent = nullptr);

public slots:
    void updateChart();
    void updateComboBoxes();

private:
    void updateLocationFilter(const QString& pollutant);
    WaterSampleDatabase* db;
    QChartView* chartView;
    QLabel* infoLabel;

    // Saved filter options
    QString selectedLocation;
    QString selectedPollutant;
    QString selectedComplianceStatus;

    // All filter options
    QComboBox* locationFilter;
    QComboBox* pollutantFilter;
    QComboBox* complianceFilter;
};
