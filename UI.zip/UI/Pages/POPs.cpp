﻿#include "POPs.hpp"
#include "utilities.hpp"
#include <QVBoxLayout>
#include <QLabel>
#include <QChartView>
#include <QLineSeries>
#include <QDateTimeAxis>
#include <QValueAxis>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QScrollArea>

POPs::POPs(WaterSampleDatabase* database, QWidget* parent)
    : QWidget(parent), db(database) {
    QVBoxLayout* mainLayout = new QVBoxLayout(this);

    // Info label for messages
    infoLabel = new QLabel("No CSV file selected", this);
    mainLayout->addWidget(infoLabel);

    // Scroll Area to contain the charts
    scrollArea = new QScrollArea(this);
    QWidget* scrollWidget = new QWidget();
    gridLayout = new QGridLayout(scrollWidget);

    scrollWidget->setLayout(gridLayout);
    scrollArea->setWidget(scrollWidget);
    scrollArea->setWidgetResizable(true);

    // Initially, only the info label is shown, not the scroll area
    scrollArea->setVisible(false);

    mainLayout->addWidget(scrollArea);
    setLayout(mainLayout);

    // Define pollutant names in the POPs category
    pollutantNames = { "PCB", "PCB Con 028", "PCB Con 101", "PCB Con 138", "PCB Con 156", "PCB Con 180" };
}

void POPs::updateChart() {
    // Clear the grid layout and charts
    while (QLayoutItem* item = gridLayout->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            gridLayout->removeWidget(widget);
            delete widget;
        }
        delete item;
    }

    if (!db || !db->createTable()) {
        infoLabel->setText("Database not available");
        infoLabel->show();
        return;
    }

    int row = 0;

    for (const QString& pollutantName : pollutantNames) {
        QVector<QPair<QDateTime, double>> dataPoints = getDataPoints(pollutantName);

        if (!dataPoints.isEmpty()) {
            QChartView* chartView = createChart(pollutantName, dataPoints);
            chartView->setMinimumSize(500, 500);
            gridLayout->addWidget(chartView, row, 0);

            row++;
        }
    }

    if (gridLayout->count() == 0) {
        infoLabel->setText("No data available for the selected pollutants");
        infoLabel->show();
    }
    else {
        infoLabel->hide();
    }

    // ������ͼ����ʹ��������ɼ�
    scrollArea->setVisible(true);
}


QChartView* POPs::createChart(const QString& pollutantName, const QVector<QPair<QDateTime, double>>& dataPoints) {
    // Line series for the connecting lines
    QLineSeries* safeSeries = new QLineSeries();
    safeSeries->setName("Safe");
    safeSeries->setColor(QColor("#5ba300"));

    QLineSeries* cautionSeries = new QLineSeries();
    cautionSeries->setName("Caution");
    cautionSeries->setColor(QColor("orange"));

    QLineSeries* exceedingSeries = new QLineSeries();
    exceedingSeries->setName("Exceeding Levels");
    exceedingSeries->setColor(QColor("#b51963"));


    // Scatter series for larger points
    QScatterSeries* safePoints = new QScatterSeries();
    safePoints->setColor(QColor("#5ba300"));
    safePoints->setMarkerSize(7.0); // Larger points


    QScatterSeries* cautionPoints = new QScatterSeries();
    cautionPoints->setColor(QColor("orange"));
    cautionPoints->setMarkerSize(7.0);

    QScatterSeries* exceedingPoints = new QScatterSeries();
    exceedingPoints->setColor(QColor("#b51963"));
    exceedingPoints->setMarkerSize(7.0);


    // Populate the series
    for (const auto& point : dataPoints) {
        double value = point.second;

        // Use compliance color logic
        QColor color = getComplianceColor(value);
        if (color == QColor("#5ba300")) {
            safeSeries->append(point.first.toMSecsSinceEpoch(), value);
            safePoints->append(point.first.toMSecsSinceEpoch(), value);
        }
        else if (color == QColor("orange")) {
            cautionSeries->append(point.first.toMSecsSinceEpoch(), value);
            cautionPoints->append(point.first.toMSecsSinceEpoch(), value);
        }
        else {
            exceedingSeries->append(point.first.toMSecsSinceEpoch(), value);
            exceedingPoints->append(point.first.toMSecsSinceEpoch(), value);
        }
    }

    // Create the chart
    QFont titleFont;
    titleFont.setBold(true);
    titleFont.setPointSize(20);

    QChart* chart = new QChart();
    chart->addSeries(safeSeries);
    chart->addSeries(cautionSeries);
    chart->addSeries(exceedingSeries);
    chart->addSeries(safePoints);
    chart->addSeries(cautionPoints);
    chart->addSeries(exceedingPoints);
    chart->setTitleFont(titleFont);
    chart->setTitle(QString("Trend for %1").arg(pollutantName));
    chart->legend()->setAlignment(Qt::AlignTop);
    chart->legend()->markers(safePoints).first()->setVisible(false);
    chart->legend()->markers(cautionPoints).first()->setVisible(false);
    chart->legend()->markers(exceedingPoints).first()->setVisible(false);


    // X-Axis: DateTime
    QDateTimeAxis* axisX = new QDateTimeAxis();
    axisX->setFormat("yyyy-MM-dd HH:mm");
    axisX->setTitleText("Sample Date Time");
    axisX->setLabelsAngle(-45);
    chart->addAxis(axisX, Qt::AlignBottom);
    safeSeries->attachAxis(axisX);
    cautionSeries->attachAxis(axisX);
    exceedingSeries->attachAxis(axisX);
    safePoints->attachAxis(axisX);
    cautionPoints->attachAxis(axisX);
    exceedingPoints->attachAxis(axisX);

    // Y-Axis: Results
    QValueAxis* axisY = new QValueAxis();
    axisY->setTitleText("Pollutant Level");
    chart->addAxis(axisY, Qt::AlignLeft);
    safeSeries->attachAxis(axisY);
    cautionSeries->attachAxis(axisY);
    exceedingSeries->attachAxis(axisY);
    safePoints->attachAxis(axisY);
    cautionPoints->attachAxis(axisY);
    exceedingPoints->attachAxis(axisY);

    // Add hover functionality for each series
    connect(safeSeries, &QLineSeries::hovered, this, &POPs::onPointHovered);
    connect(cautionSeries, &QLineSeries::hovered, this, &POPs::onPointHovered);
    connect(exceedingSeries, &QLineSeries::hovered, this, &POPs::onPointHovered);

    QChartView* chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    return chartView;
}


QVector<QPair<QDateTime, double>> POPs::getDataPoints(const QString& pollutantName) {
    QVector<QPair<QDateTime, double>> points;

    QSqlQuery query;
    query.prepare("SELECT sampleDateTime, result FROM water_samples WHERE determinandLabel LIKE :pollutantName");
    query.bindValue(":pollutantName", pollutantName + "%");

    if (!query.exec()) {
        qDebug() << "Database query failed for" << pollutantName << ":" << query.lastError().text();
        return points;
    }

    while (query.next()) {
        QDateTime dateTime = QDateTime::fromString(query.value("sampleDateTime").toString(), Qt::ISODate);
        double result = query.value("result").toDouble();
        points.append(qMakePair(dateTime, result));
    }

    // Sort points by time
    std::sort(points.begin(), points.end(), [](const auto& a, const auto& b) {
        return a.first < b.first;
        });

    return points;
}

void POPs::onPointHovered(const QPointF& point, bool state) {
    if (state) { // Mouse is hovering over a point
        QString details = QString(
            "Pollutant Level: %1\nCompliance Status: %2\nRisk: %3"
        ).arg(point.y())
            .arg(getComplianceStatus(point.y()))
            .arg(getRiskDescription(point.y()));
        QToolTip::showText(QCursor::pos(), details, this);
    }
    else { // Mouse left the point
        QToolTip::hideText();
    }
}

QString POPs::getComplianceStatus(double value) const {
    if (value < 50) return "Safe";
    if (value < 100) return "Caution";
    return "Exceeding";
}

QString POPs::getRiskDescription(double value) const {
    if (value < 50) return "Low risk to environment and health.";
    if (value < 100) return "Moderate risk. Take precautions.";
    return "High risk! Immediate action required.";
}