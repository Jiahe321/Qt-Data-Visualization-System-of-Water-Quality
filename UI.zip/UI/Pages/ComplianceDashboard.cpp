#include "ComplianceDashboard.hpp"
#include <QVBoxLayout>
#include <QLabel>
#include <QChartView>

// Constructor
ComplianceDashboard::ComplianceDashboard(WaterSampleDatabase* database, QWidget* parent)
    : QWidget(parent), db(database), chartView(nullptr),
    selectedLocation("All Locations"),
    selectedPollutant("All Pollutants"),
    selectedComplianceStatus("All Samples") {

    QVBoxLayout* layout = new QVBoxLayout(this);

    // Create all filters
    locationFilter = new QComboBox(this);
    locationFilter->addItem("All Locations");  // Add default "All Locations"
    locationFilter->setDisabled(true);  // Initially disabled

    pollutantFilter = new QComboBox(this);
    pollutantFilter->addItem("All Pollutants"); // Add default "All Pollutants"
    pollutantFilter->setDisabled(true);  // Initially disabled

    complianceFilter = new QComboBox(this);
    complianceFilter->addItem("All Samples");
    complianceFilter->addItem("Compliant Only");
    complianceFilter->addItem("Non-Compliant Only");
    complianceFilter->setDisabled(true);

    // Add filters to layout
    QHBoxLayout* filterLayout = new QHBoxLayout();
    filterLayout->addWidget(new QLabel(tr("Location:")));
    filterLayout->addWidget(locationFilter);
    filterLayout->addWidget(new QLabel(tr("Pollutant:")));
    filterLayout->addWidget(pollutantFilter);
    filterLayout->addWidget(new QLabel(tr("Compliance:")));
    filterLayout->addWidget(complianceFilter);

    // Set stretch factors to distribute space evenly
    filterLayout->setStretch(0, 0);
    filterLayout->setStretch(1, 1);
    filterLayout->setStretch(2, 0);
    filterLayout->setStretch(3, 1);
    filterLayout->setStretch(4, 0);
    filterLayout->setStretch(5, 1);

    layout->addLayout(filterLayout);

    // Default info label: no CSV file selected
    infoLabel = new QLabel(tr("No CSV file selected"), this);
    layout->addWidget(infoLabel);

    setLayout(layout);

    // Connect signals and slots to update chart and filters
    connect(locationFilter, &QComboBox::currentTextChanged, this, [=](const QString& text) {
        selectedLocation = text;
        emit updateChart();
    });
    connect(pollutantFilter, &QComboBox::currentTextChanged, this, [=](const QString& text) {
        selectedPollutant = text;

        // Filter locations based on selected pollutant
        updateLocationFilter(text);

        emit updateChart();
        });

    connect(complianceFilter, &QComboBox::currentTextChanged, this, [=](const QString& text) {
        selectedComplianceStatus = text;
        updateLocationFilter(selectedPollutant);
        emit updateChart();
    });
}

// Slot to update the chart
void ComplianceDashboard::updateChart() {
    // If chart view already exists, remove it and delete it
    if (chartView) {
        layout()->removeWidget(chartView);
        delete chartView;
        chartView = nullptr;
    }

    // If no database available, show error message and return
    if (!db) {
        infoLabel->setText(tr("Database not available"));
        infoLabel->show();
        return;
    }

    // Get selected filters
    QString location = locationFilter->currentText();
    QString determinand = pollutantFilter->currentText();
    QString compliance = complianceFilter->currentText();

    // Create chart view using db methods
    chartView = db->createComplianceChart(determinand, location, compliance);

    if (chartView) {
        layout()->addWidget(chartView);
        infoLabel->hide();// Hide info label if chart is created successfully
    }
    else {
        infoLabel->setText(tr("No data available for the selected filters"));
        infoLabel->show();
    }
}

void ComplianceDashboard::updateComboBoxes() {
    // Clear and update Location ComboBox
    locationFilter->clear();
    locationFilter->addItem("All Locations");

    // Get all unique locations
    QStringList locations = db->getUniqueEntries("", "location", "");
    if (!locations.isEmpty()) {
        locationFilter->addItems(locations);
    }

    // Clear and update Pollutant ComboBox
    pollutantFilter->clear();
    pollutantFilter->addItem("All Pollutants");

    // Get all unique pollutants
    QStringList pollutants = db->getUniqueEntries("", "pollutant");
    if (!pollutants.isEmpty()) {
        pollutantFilter->addItems(pollutants);
    }

    // Update location filter based on selected pollutant and compliance
    updateLocationFilter("All Pollutants");

    // Enable all ComboBoxes
    locationFilter->setEnabled(true);
    pollutantFilter->setEnabled(true);
    complianceFilter->setEnabled(true);
}


void ComplianceDashboard::updateLocationFilter(const QString& pollutant) {
    locationFilter->clear();
    locationFilter->addItem("All Locations");

    QStringList locations;
    QString compliance = complianceFilter->currentText();

    if (pollutant == "All Pollutants") {
        locations = db->getUniqueEntries("", "location", compliance == "All Samples" ? "" : compliance);
    }
    else {
        locations = db->getUniqueEntries(pollutant, "location", compliance == "All Samples" ? "" : compliance);
    }

    if (!locations.isEmpty()) {
        locationFilter->addItems(locations);
    }
}
