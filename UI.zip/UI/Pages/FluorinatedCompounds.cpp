#include "FluorinatedCompounds.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QChartView>
#include <QScrollArea>

// Constructor
FluorinatedCompounds::FluorinatedCompounds(WaterSampleDatabase* database, QWidget* parent)
    : QWidget(parent), db(database), chartView(nullptr) {

    // Create the main horizontal layout
    QHBoxLayout* mainLayout = new QHBoxLayout(this);

    // Create the widget for vertical1 layout
    QWidget* vertical1Widget = new QWidget(this);
    QVBoxLayout* vertical1 = new QVBoxLayout(vertical1Widget); // Set the layout for the widget

    compoundComboBox = new QComboBox(this);
    locationComboBox = new QComboBox(this);

    // Set initial states for the combo boxes
    compoundComboBox->setEnabled(false);
    locationComboBox->setEnabled(false);

    // Add widgets to vertical1
    vertical1->addWidget(new QLabel("Select Fluorinated Compound:", this));
    vertical1->addWidget(compoundComboBox);
    vertical1->addWidget(new QLabel("Select Location:", this));
    vertical1->addWidget(locationComboBox);

    // Initialize the scroll area for hazard info
    hazardScrollArea = new QScrollArea(this);
    hazardLabel = new QLabel(this);
    hazardLabel->setWordWrap(true); // Enable word wrapping for text
    hazardScrollArea->setWidget(hazardLabel);
    hazardScrollArea->setWidgetResizable(true); // Allow resizing with the parent widget
    vertical1->addWidget(hazardScrollArea);

    // Set the maximum width of the vertical1 widget to one-third of the window width
    vertical1Widget->setMaximumWidth(300);

    // Create vertical2 layout for chart and info label
    QVBoxLayout* vertical2 = new QVBoxLayout();
    infoLabel = new QLabel("No CSV file selected", this);
    vertical2->addWidget(infoLabel);

    // Initialize chart area
    chartView = new QChartView(this);
    vertical2->addWidget(chartView);

    // Add vertical layouts to the main horizontal layout
    mainLayout->addWidget(vertical1Widget);  // Add the vertical1 widget instead of the layout
    mainLayout->addLayout(vertical2);

    // Set the main layout for the widget
    setLayout(mainLayout);

    connectSlots();  // Connect signals to slots

}

void FluorinatedCompounds::connectSlots() {
    // Connect signals to slots
    connect(compoundComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
        this, &FluorinatedCompounds::onCompoundChanged);

    connect(locationComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
        this, &FluorinatedCompounds::onLocationChanged);

    connect(compoundComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
        this, &FluorinatedCompounds::onCompoundChanged);
}

// Slot to handle compound change
void FluorinatedCompounds::onCompoundChanged(int index) {
    if (index == -1) return;  // If no valid selection, return

    QString selectedCompound = compoundComboBox->currentText();
    updateLocations(selectedCompound);  // Update locations based on the selected compound
    updateChart();  // Update chart based on the selected compound and location
    showHazardInfo(selectedCompound);  // Display hazard information for the selected compound
}

// Slot to handle location change
void FluorinatedCompounds::onLocationChanged(int index) {
    if (index == -1) return;  // If no valid selection, return

    updateChart();  // Update chart based on the current compound and location
}

// Slot to update the available options for combo boxes
void FluorinatedCompounds::updateComboBoxes() {
    if (!db) {
        qWarning() << "Database not available";
        return;
    }

    // Clear existing content
    compoundComboBox->clear();
    locationComboBox->clear();

    // Fetch pollutants (compounds) from the database
    QStringList compounds = db->getUniqueEntries("perfluoro", "pollutant");
    if (!compounds.isEmpty()) {
        compoundComboBox->addItems(compounds);
        compoundComboBox->setEnabled(true);

        // Default to the first compound and load its locations
        if (!compounds.isEmpty()) {
            QString firstCompound = compounds.first();
            updateLocations(firstCompound);
        }
    }
    else {
        compoundComboBox->setEnabled(false);
    }
}

// Slot to update locations for a specific compound
void FluorinatedCompounds::updateLocations(const QString& compound) {
    locationComboBox->clear();

    // Fetch locations from the database based on the selected compound (pollutant)
    QStringList locations = db->getUniqueEntries(compound, "location");
    if (!locations.isEmpty()) {
        locationComboBox->addItems(locations);
        locationComboBox->setEnabled(true);
    }
    else {
        locationComboBox->setEnabled(false);
    }
}

void FluorinatedCompounds::updateChart() {
    // If there's an existing chart, remove and delete it
    if (chartView) {
        layout()->removeWidget(chartView);
        delete chartView;
        chartView = nullptr;
    }

    // Check if the database is available
    if (!db) {
        infoLabel->setText("Database not available");
        infoLabel->show();
        return;
    }

    // Get selected filters
    QString selectedCompound = compoundComboBox->currentText();
    QString selectedLocation = locationComboBox->currentText();
    qDebug() << "Selected compound: " << selectedCompound;
    qDebug() << "Selected location: " << selectedLocation;

    // Generate a chart for the selected filters (without date range)
    chartView = db->createFCChart(selectedCompound, selectedLocation);

    if (chartView) {
        layout()->addWidget(chartView); // Add chart to the layout
        infoLabel->hide(); // Hide the info label
    }
    else {
        infoLabel->setText("No data available for the selected filters");
        infoLabel->show();
    }
}

// Slot to show hazard information for a selected compound
void FluorinatedCompounds::showHazardInfo(const QString& compound) {
    QString hazardInfo;
    if (compound == "PFHxSA") {
        hazardInfo = "This compound has significant environmental persistence and bioaccumulation potential. Avoid exposure to large quantities.";
    }
    else if (compound == "9Cl-PF3ONS") {
        hazardInfo = "This compound may cause health issues if ingested in large quantities. Always handle with care.";
    }
    else if (compound == "5:3 FTCA") {
        hazardInfo = "This compound poses potential risks to aquatic ecosystems due to its persistence. Use personal protective equipment (PPE) when handling.";
    }
    else {
        hazardInfo = "No hazard information available for the selected compound.";
    }
    hazardLabel->setText(hazardInfo);
}
