#include "Dashboard.hpp"

Dashboard::Dashboard(WaterSampleDatabase* db, QWidget* parent)
    : QWidget(parent), db(db), isCSVLoaded(false) {
    setMaximumSize(2000, 700);
    CSVLoaded = false;
    createWidgets();
}

void Dashboard::createWidgets() {
    mainLayout = new QVBoxLayout(this);
    mainLayout->addStretch();

    titleLabel = new QLabel(tr("Water Quality Dashboard"), this);
    titleLabel->setStyleSheet("font-size: 20px; font-weight: bold;");
    titleLabel->setAlignment(Qt::AlignCenter);

    QLabel* overviewLabel = new QLabel(tr("Welcome to the Water Quality Dashboard!\n\n"
        "Use the dropdown menu below to explore different sections:\n"
        "- Pollutants Overview\n"
        "- Persistent Organic Pollutants (POPs)\n"
        "- Environmental Litter Indicators\n"
        "- Fluorinated Compounds\n"
        "- Compliance Dashboard\n\n"
        "You can also navigate with the tabs above for more detailed information about each section."));
    overviewLabel->setWordWrap(true);
    overviewLabel->setAlignment(Qt::AlignLeft | Qt::AlignTop);
    overviewLabel->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);

    pageSelector = new QComboBox(this);
    pageSelector->addItem(tr("Pollutants Overview"));
    pageSelector->addItem(tr("Persistent Organic Pollutants (POPs)"));
    pageSelector->addItem(tr("Environmental Litter Indicators"));
    pageSelector->addItem(tr("Fluorinated Compounds"));
    pageSelector->addItem(tr("Compliance Dashboard"));
    pageSelector->setStyleSheet("font-size: 14px; padding: 5px;");

    // Add a label to display the current selected page information
    pageInfoLabel = new QLabel(tr("Select a page to view its details."), this);
    pageInfoLabel->setWordWrap(true);
    pageInfoLabel->setStyleSheet("background-color: #e0e0e0; padding: 10px; border: 1px solid #dcdcdc; border-radius: 5px; color: #333;");

    pollutantSelector = new QComboBox(this);
    pollutantSelector->setEnabled(false); // Initially disabled
    pollutantSelector->addItem(tr("CSV not loaded")); // Default message

    infoDisplayLabel = new QLabel(tr("Select a pollutant to view its definition. You need to load CSV file before selecting a pollutant."), this);
    infoDisplayLabel->setWordWrap(true);
    infoDisplayLabel->setStyleSheet("background-color: #f5f5f5; padding: 10px; border: 1px solid #dcdcdc; border-radius: 5px; color: #333;");

    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(overviewLabel);
    mainLayout->addWidget(pageSelector);
    mainLayout->addWidget(pageInfoLabel);  // Add the page information display
    mainLayout->addWidget(pollutantSelector);  // Keep pollutantSelector below page info
    mainLayout->addWidget(infoDisplayLabel);  // Keep infoDisplayLabel below pollutantSelector
    mainLayout->addStretch();

    connect(pageSelector, &QComboBox::currentIndexChanged, this, &Dashboard::onPageSelected);
    connect(pollutantSelector, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &Dashboard::onPollutantSelected);
}

void Dashboard::onPageSelected(int index) {
    switch (index) {
    case 0:
        pageInfoLabel->setText(tr("Pollutants Overview:\n\n"
            "Common Heavy Metals: Lead, Mercury, Cadmium\n"
            "Common Nutrients: Nitrate, Phosphate.\n"
            "Common Organic Compounds: Chlorofoam\n"
            "\nThis page display detailed information on common pollutants."));
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 1:
        pageInfoLabel->setText(tr("Persistent Organic Pollutants (POPs):\n\n"
            "This page display details about persistent organic pollutants.\n"
            "Present data on persistent organic pollutants"
            "due to their long-lasting impact on the environment and health."));
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 2:
        pageInfoLabel->setText(tr("Environmental Litter Indicators:\n\n"
            "This page display information about environmental litter."
            " Check indicators related to environmental litter."));
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 3:
        pageInfoLabel->setText(tr("Fluorinated Compounds:\n\n"
            "This page display information about fluorinated compounds,"
            "which are monitored for their environmental persistence and influence to health."));
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 4:
        pageInfoLabel->setText(tr("Compliance Dashboard:\n\n"
            "Check compliance statistics.\n"
            "An overview of regulatory compliance across all pollutants,"
            "showing which substances meet or exceed safety standards."));
        pollutantSelector->clear();
        pollutantSelector->setEnabled(false);
        if (CSVLoaded) { infoDisplayLabel->setText(""); }
        break;
    default:
        pageInfoLabel->setText(tr("Select a page to view its details."));
        if (CSVLoaded) { infoDisplayLabel->setText(""); }
        break;
    }
}

void Dashboard::updatePollutants() {
    CSVLoaded = true;
    QSqlQuery query;
    QStringList pollutants;

    // Use the index of the current page instead of its text
    int categoryIndex = pageSelector->currentIndex();

    switch (categoryIndex) {
    case 0: // Pollutants Overview
        pollutants << "Lead - as Pb"
            << "Mercury - Hg"
            << "Cadmium - Cd"
            << "Chromium - Cr"
            << "Nitrate-N"
            << "Phosphate"
            << "Chloroform"
            << "112TCEthan";
        break;
    case 1: // Persistent Organic Pollutants (POPs)
        query.prepare("SELECT determinandLabel FROM water_samples WHERE determinandDefinition LIKE '%PCB%'");
        if (query.exec()) {
            while (query.next()) {
                pollutants.append(query.value(0).toString());
            }
        }
        break;
    case 2: // Environmental Litter Indicators
        pollutants << "BWP - O.L."
            << "SewageDebris"
            << "TarryResidus";
        break;
    case 3: // Fluorinated Compounds
        query.prepare("SELECT determinandLabel FROM water_samples WHERE determinandDefinition LIKE '%perfluoro%'");
        if (query.exec()) {
            while (query.next()) {
                pollutants.append(query.value(0).toString());
            }
        }
        break;
    case 4: // Compliance Dashboard
        // Compliance dashboard doesn't use pollutants
        pollutants.clear();
        break;
    default:
        pollutants.clear();
        break;
    }

    // Update the pollutant selector with the retrieved list
    pollutantSelector->clear();
    pollutantSelector->addItems(pollutants);
    pollutantSelector->setEnabled(!pollutants.isEmpty());
}

void Dashboard::onPollutantSelected(int index) {
    QString selectedPollutant = pollutantSelector->itemText(index);

    QSqlQuery query;
    query.prepare("SELECT determinandDefinition FROM water_samples WHERE determinandLabel = ?");
    query.addBindValue(selectedPollutant);

    if (!query.exec()) {
        qDebug() << "Query execution failed: " << query.lastError();
        return;
    }

    if (query.next()) {
        QString definition = query.value(0).toString();
        infoDisplayLabel->setText(tr("Definition: %1").arg(definition));
    }
}
