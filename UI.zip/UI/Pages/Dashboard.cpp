#include "Dashboard.hpp"

Dashboard::Dashboard(WaterSampleDatabase* db, QWidget* parent)
    : QWidget(parent), db(db), isCSVLoaded(false) {
    setMaximumSize(2000, 700);
    CSVLoaded = false;
    createWidgets();
}

void Dashboard::createWidgets() {
    mainLayout = new QVBoxLayout(this);
    mainLayout->addStretch();

    titleLabel = new QLabel(tr("Water Quality Dashboard"), this);
    titleLabel->setStyleSheet("font-size: 20px; font-weight: bold;");
    titleLabel->setAlignment(Qt::AlignCenter);

    QLabel* overviewLabel = new QLabel(tr("Welcome to the Water Quality Dashboard!<br><br>"
        "Use the dropdown menu below to explore different sections:<br>"
        "- Pollutants Overview<br>"
        "- Persistent Organic Pollutants (POPs)<br>"
        "- Environmental Litter Indicators<br>"
        "- Fluorinated Compounds<br>"
        "- Compliance Dashboard<br><br>"
        "This data is taken from:"
        "<a href= 'https://environment.data.gov.uk/water-quality/view/download'> Open WIMS Data</a> <br><br>"
        "You can also navigate with the tabs above for more detailed information about each section."));
    overviewLabel->setTextFormat(Qt::RichText); // Enable HTML rendering
    overviewLabel->setOpenExternalLinks(true); // Enable clickable links
    overviewLabel->setWordWrap(true);
    overviewLabel->setAlignment(Qt::AlignLeft | Qt::AlignTop);
    overviewLabel->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);

    pageSelector = new QComboBox(this);
    pageSelector->addItem(tr("Select a page to know more about")); // Placeholder item
    pageSelector->addItem(tr("Pollutants Overview"));
    pageSelector->addItem(tr("Persistent Organic Pollutants (POPs)"));
    pageSelector->addItem(tr("Environmental Litter Indicators"));
    pageSelector->addItem(tr("Fluorinated Compounds"));
    pageSelector->addItem(tr("Compliance Dashboard"));
    pageSelector->setStyleSheet("font-size: 14px; padding: 5px;");

    // Add a label to display the current selected page information
    pageInfoLabel = new QLabel(tr("Select a page to view its details."), this);
    pageInfoLabel->setWordWrap(true);
    pageInfoLabel->setStyleSheet("background-color: #e0e0e0; padding: 10px; border: 1px solid #dcdcdc; border-radius: 5px; color: #333;");

    pollutantSelector = new QComboBox(this);
    pollutantSelector->setEnabled(false); // Initially disabled
    pollutantSelector->addItem(tr("CSV not loaded")); // Default message

    infoDisplayLabel = new QLabel(tr("Select a pollutant to view its definition. You need to load CSV file before selecting a pollutant."), this);
    infoDisplayLabel->setWordWrap(true);
    infoDisplayLabel->setStyleSheet("background-color: #f5f5f5; padding: 10px; border: 1px solid #dcdcdc; border-radius: 5px; color: #333;");

    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(overviewLabel);
    mainLayout->addWidget(pageSelector);
    mainLayout->addWidget(pageInfoLabel);  // Add the page information display
    mainLayout->addWidget(pollutantSelector);  // Keep pollutantSelector below page info
    mainLayout->addWidget(infoDisplayLabel);  // Keep infoDisplayLabel below pollutantSelector
    mainLayout->addStretch();

    connect(pageSelector, &QComboBox::currentIndexChanged, this, &Dashboard::onPageSelected);
    connect(pollutantSelector, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &Dashboard::onPollutantSelected);
}

void Dashboard::onPageSelected(int index) {
    if (index == 0) { // Placeholder case
        pageInfoLabel->setText(tr("Select a page to view its details."));
        pageInfoLabel->setTextFormat(Qt::PlainText);
        pollutantSelector->setEnabled(false);
        infoDisplayLabel->setText(tr("Select a pollutant to view its definition. You need to load a CSV file before selecting a pollutant."));
        return; // Skip further logic
    }
    switch (index) {
    case 1:
        pageInfoLabel->setTextFormat(Qt::RichText); // Enable rich text (HTML)
        pageInfoLabel->setWordWrap(true);          // Enable word wrapping
        pageInfoLabel->setText(tr("Pollutants Overview:<br><br>"
            "Detailed data about common pollutants found in water:<br>"
            "- Common Heavy Metals: Lead, Mercury, Cadmium.<br>"
            "- Nutrients: Nitrate, Phosphate.<br>"
            "- Organic Compounds: Chloroform, etc.<br><br>"
            "Learn about their sources, health impacts, and removal methods:<br>"
            "<a href='https://www.epa.gov/water-research'>More about water pollutants</a>"));
        pageInfoLabel->setOpenExternalLinks(true); // Enable clickable links
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 2:
        pageInfoLabel->setTextFormat(Qt::RichText); // Enable rich text (HTML)
        pageInfoLabel->setWordWrap(true);          // Enable word wrapping
        pageInfoLabel->setText(tr("Persistent Organic Pollutants (POPs):<br><br>"
            "Explore data on persistent organic pollutants, such as PCBs and DDT"
            "These chemicals persist in the environment and pose long-term risks"
            "to ecosystems and human health:<br>"
            "<a href='https://www.gov.uk/guidance/using-persistent-organic-pollutants-pops'>Learn more about POPs</a>"));
        pageInfoLabel->setOpenExternalLinks(true); // Enable clickable links
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 3:
        pageInfoLabel->setTextFormat(Qt::RichText); // Enable rich text (HTML)
        pageInfoLabel->setWordWrap(true);          // Enable word wrapping
        pageInfoLabel->setText(tr("Environmental Litter Indicators:\n\n"
            "Get insights into litter indicators, including:<br><br>"
            "- Sewage Debris.<br>"
            "- Oil Residues.<br>"
            "- Microplastics.<br><br>"
            "Understand the impact of litter on aquatic environments:<br>"
            "<a href='https://www.unep.org/topics/ocean-seas-and-coasts/ecosystem-degradation-pollution/plastic-pollution-marine-litter'>More about litter and plastics</a>"));
        pageInfoLabel->setOpenExternalLinks(true); // Enable clickable links
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 4:
        pageInfoLabel->setTextFormat(Qt::RichText); // Enable rich text (HTML)
        pageInfoLabel->setWordWrap(true);          // Enable word wrapping
        pageInfoLabel->setText(tr("Fluorinated Compounds:<br><br>"
            "This section covers fluorinated compounds, known for their persistence "
            "in the environment. Examples include PFAS and related compounds:<br>"
            "<a href='https://www.epa.gov/pfas'>Learn more about PFAS</a>"));
        pageInfoLabel->setOpenExternalLinks(true); // Enable clickable links
        if (CSVLoaded) { updatePollutants(); }
        break;
    case 5:
        pageInfoLabel->setTextFormat(Qt::RichText); // Enable rich text (HTML)
        pageInfoLabel->setWordWrap(true);          // Enable word wrapping
        pageInfoLabel->setText(tr("Compliance Dashboard:<br><br>"
            "Review compliance data across all monitored pollutants. "
            "See which regions and pollutants meet safety standards "
            "and identify areas for improvement:<br>"
            "<a href='https://www.epa.gov/compliance'>Understand compliance requirements</a>"));
        pageInfoLabel->setOpenExternalLinks(true); // Enable clickable links
        pollutantSelector->clear();
        pollutantSelector->setEnabled(false);
        if (CSVLoaded) { infoDisplayLabel->setText(""); }
        break;
    default:
        pageInfoLabel->setTextFormat(Qt::RichText);
        pageInfoLabel->setWordWrap(true);
        pageInfoLabel->setText(tr("Select a page to view its details."));
        pageInfoLabel->setOpenExternalLinks(false); // Disable links for default case
        if (CSVLoaded) { infoDisplayLabel->setText(""); }
        break;
    }
}

void Dashboard::updatePollutants() {
    CSVLoaded = true;
    QSqlQuery query;
    QStringList pollutants;

    // Use the index of the current page instead of its text
    int categoryIndex = pageSelector->currentIndex();

    // Ensure that pollutants are updated for pages that require it
    switch (categoryIndex) {
    case 1: // Pollutants Overview
        pollutants << "Lead - as Pb"
            << "Mercury - Hg"
            << "Cadmium - Cd"
            << "Chromium - Cr"
            << "Nitrate-N"
            << "Phosphate"
            << "Chloroform"
            << "112TCEthan";
        break;
    case 2: // Persistent Organic Pollutants (POPs)
        query.prepare("SELECT determinandLabel FROM water_samples WHERE determinandDefinition LIKE '%PCB%'");
        if (query.exec()) {
            while (query.next()) {
                pollutants.append(query.value(0).toString());
            }
        }
        break;
    case 3: // Environmental Litter Indicators
        pollutants << "BWP - O.L."
            << "SewageDebris"
            << "TarryResidus";
        break;
    case 4: // Fluorinated Compounds
        query.prepare("SELECT determinandLabel FROM water_samples WHERE determinandDefinition LIKE '%perfluoro%'");
        if (query.exec()) {
            while (query.next()) {
                pollutants.append(query.value(0).toString());
            }
        }
        break;
    case 5: // Compliance Dashboard
        // Compliance dashboard doesn't use pollutants
        pollutants.clear();
        break;
    default:
        pollutants.clear();
        break;
    }

    // Update the pollutant selector with the updated list of pollutants
    pollutantSelector->clear();
    if (!pollutants.isEmpty()) {
        pollutantSelector->addItems(pollutants);
        pollutantSelector->setEnabled(true); // Enable the selector if pollutants are available
    }
    else {
        pollutantSelector->addItem(tr("No pollutants available for this section"));
        pollutantSelector->setEnabled(false); // Disable selector if no pollutants
    }

    // Optionally, reset the info display if there are no pollutants
    if (pollutants.isEmpty()) {
        infoDisplayLabel->setText(tr("No pollutants available for this section."));
    }
    else {
        infoDisplayLabel->setText(tr("Select a pollutant to view its definition."));
    }
}

void Dashboard::onPollutantSelected(int index) {
    QString selectedPollutant = pollutantSelector->itemText(index);

    QSqlQuery query;
    query.prepare("SELECT determinandDefinition FROM water_samples WHERE determinandLabel = ?");
    query.addBindValue(selectedPollutant);

    if (!query.exec()) {
        qDebug() << "Query execution failed: " << query.lastError();
        return;
    }

    if (query.next()) {
        QString definition = query.value(0).toString();
        infoDisplayLabel->setText(tr("Definition: %1").arg(definition));
    }
}
